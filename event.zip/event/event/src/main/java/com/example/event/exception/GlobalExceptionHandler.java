package com.example.event.exception;

import java.util.LinkedHashMap;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.servlet.mvc.method.annotation.ResponseEntityExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler extends ResponseEntityExceptionHandler {

    /**
     * This is a Java exception handler that returns a custom response entity with details about a
     * resource not found error.
     * 
     * @param ex "ex" is an instance of the "ResourceNotFound" class, which is an exception that can be
     * thrown when a requested resource is not found. The code block is an exception handler that
     * catches this exception and returns a custom response entity with a map of details about the
     * exception.
     * @return A ResponseEntity object containing a map of information about the ResourceNotFound
     * exception, including the ID, description, and status code, with a HTTP status code of NOT_FOUND.
     */

    @ExceptionHandler(ResourceNotFound.class)
    public ResponseEntity<Object> handleResourceNotFound(ResourceNotFound ex) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("id", ex.getMessage());
        body.put("description", ex.getDescription());
        body.put("statuscode", ex.getStatusCode());
        return new ResponseEntity<>(body, HttpStatus.NOT_FOUND);
    }

    /**
     * This is a Java exception handler that returns a custom response entity for a
     * BadRequestException.
     * 
     * @param ex "ex" is the instance of the "BadRequestException" class that was thrown when an error
     * occurred in the code. It contains information about the error, such as the error message,
     * description, and status code. The purpose of the method is to handle this exception and return a
     * response entity with the
     * @return A ResponseEntity object containing a map with the message, description, and status code
     * of a BadRequestException, with a HTTP status code of 400 (Bad Request).
     */

    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<Object> handleBadRequest(BadRequestException ex) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("message", ex.getMessage());
        body.put("description", ex.getDescription());
        body.put("statuscode", ex.getStatusCode());
        return new ResponseEntity<>(body, HttpStatus.BAD_REQUEST);
    }
    
    /**
     * This is a Java exception handler that returns a response entity with a message, description, and
     * status code for a ConflictException.
     * 
     * @param ex "ex" is the instance of the "ConflictException" class that was thrown and caught by
     * the exception handler. It contains information about the exception, such as the error message,
     * description, and status code.
     * @return A ResponseEntity object containing a map of information about the ConflictException,
     * including the message, description, and status code, with a HTTP status code of CONFLICT.
     */
    
    @ExceptionHandler(ConflictException.class)
    public ResponseEntity<Object> handleResourceConflict(ConflictException ex) {
        Map<String, Object> body = new LinkedHashMap<>();
        body.put("message", ex.getMessage());
        body.put("description", ex.getDescription());
        body.put("statusCode", ex.getStatusCode());
        return new ResponseEntity<>(body, HttpStatus.CONFLICT);
    }
}
