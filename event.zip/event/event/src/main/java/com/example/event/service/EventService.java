package com.example.event.service;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.event.dto.AttendeeDto;
import com.example.event.dto.EventDto;
import com.example.event.entity.Attendee;
import com.example.event.entity.Event;
import com.example.event.exception.BadRequestException;
import com.example.event.exception.ConflictException;
import com.example.event.exception.ResourceNotFound;
import com.example.event.repository.AttendeeRepository;
import com.example.event.repository.EventRepository;


@Service
public class EventService {

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private AttendeeRepository attendeeRepository;

    private static final Logger logger = LoggerFactory.getLogger(EventService.class);

    /**
     * This function creates an event for a given attendee and returns the event ID.
     * 
     * @param attendeeId The ID of the attendee who is registering for the event.
     * @param eventDto An object of type EventDto which contains the details of the event to be
     * created.
     * @return The method is returning a long value which represents the ID of the created event.
     */

    public long createEvent(long attendeeId,EventDto eventDto) {
        Attendee attendee=attendeeRepository.findById(attendeeId).orElseThrow(() -> {
            logger.warn("Attendee is not found: {}", attendeeId);
            return new ResourceNotFound(String.valueOf(attendeeId), "Attendee is not Found.", 404);
        });
        logger.info("Creating events with eventID: {}", eventDto.getEventId());
        if (eventDto.getEventName() == null || eventDto.getEventStatus() == null || eventDto.getEventDate() == null || eventDto.getStartTime() == null || eventDto.getEndTime() == null || eventDto.getVenue() == null) {
            logger.error("Invalid request: All fields must be provided");
            throw new BadRequestException("Invalid request", "All fields must be provided", 400);
        }
        if (isDateAlreadyBooked(eventDto.getEventDate()) && isTimeAlreadyBooked(eventDto.getStartTime()) && isVenueAlreadyBooked(eventDto.getVenue())) {
            throw new ConflictException("Event already booked", "Event conflict", 409);
        }   
        Event event = convertEventDtoToEvent(eventDto);
        attendee.setRegisteredEvent(event);
        eventRepository.save(event);
        attendeeRepository.save(attendee);
        logger.debug("Event is registered for id: {}",attendeeId);
        return event.getEventId();
    }

    /**
     * This Java function deletes an event by its ID from a repository and returns a success message.
     * 
     * @param eventId The ID of the event that needs to be deleted from the event repository.
     * @return The method is returning a String message "Event Deleted Successfully" after deleting an
     * event with the given ID from the event repository.
     */

    public String deleteEventById(long eventId) {
        logger.info("Deleting event with ID: {}", eventId);
        Optional<Event> eventOptional = eventRepository.findById(eventId);
        if (eventOptional.isEmpty()) {
            logger.warn("Event ID is not found: {}", eventId);
            throw new ResourceNotFound(String.valueOf(eventId), "Event is not found", 404);
        }
        Event event = eventOptional.get();
        List<Attendee> attendees = attendeeRepository.findByRegisteredEvent(event);
        if (!attendees.isEmpty()) {
            // Handle the constraint violation by disassociating attendees from the event
            for (Attendee attendee : attendees) {
                attendee.setRegisteredEvent(null);
                attendeeRepository.save(attendee);
            }
        }
        
        eventRepository.delete(event);
        return "Event Deleted Successfully";
    }

    /**
     * This Java function updates an event in a repository based on the provided event DTO and event
     * ID, with error handling for missing fields and conflicts.
     * 
     * @param eventDto An object of type EventDto that contains the updated information for the event.
     * @param eventId The ID of the event that needs to be updated.
     * @return The method is returning a String message "Event updated successfully".
     */

    public String updateEventById(EventDto eventDto, long eventId) {
        logger.info("Updating event with ID: {}", eventId);
        Event event = eventRepository.findById(eventId).orElseThrow(() -> {
            logger.error("Event is not found: {}", eventId);
            return new ResourceNotFound(String.valueOf(eventId), "Event is not Found.", 404);
        });
        if (eventDto.getEventName() == null || eventDto.getEventStatus() == null || eventDto.getEventDate() == null || eventDto.getStartTime() == null || eventDto.getEndTime() == null || eventDto.getVenue() == null) {
            logger.error("Invalid request: All fields must be provided");
            throw new BadRequestException("Invalid request", "All fields must be provided", 400);
        }
        if (isDateAlreadyBooked(eventDto.getEventDate()) && isTimeAlreadyBooked(eventDto.getStartTime()) && isVenueAlreadyBooked(eventDto.getVenue())) {
            logger.error("Event already exists");
            throw new ConflictException("Event already booked", "Event conflict", 409);
        }
        event.setEventName(eventDto.getEventName());
        event.setEventDescription(eventDto.getEventDescription());
        event.setEventStatus(eventDto.getEventStatus());
        event.setStartTime(eventDto.getStartTime());
        event.setEndTime(eventDto.getEndTime());
        event.setEventDate(eventDto.getEventDate());
        event.setVenue(eventDto.getVenue());
        eventRepository.save(event);
        return "Event updated successfully";
    }

    /**
     * This function retrieves an event entity by its ID from a repository and throws a custom
     * exception if it is not found.
     * 
     * @param eventId a long integer representing the ID of the event that needs to be retrieved from
     * the database.
     * @return The method `getEntityById` returns an `Event` object with the specified `eventId`. If
     * the event is not found in the `eventRepository`, it throws a `ResourceNotFound` exception with a
     * message indicating that the event is not found and a status code of 404.
     */

    public Event getEntityById(long eventId) {
        logger.info("Getting event with ID: {}", eventId);
        return eventRepository.findById(eventId).orElseThrow(() -> {
            logger.error("Event is not found: {}", eventId);
            return new ResourceNotFound(String.valueOf(eventId), "Event is not Found.", 404);
        });
    }

    /**
     * This function reads all events from the event repository and returns them as a list.
     * 
     * @return A list of all events from the event repository.
     */
    
    public List<Event> readAllEvent() {
        logger.info("Reading all events");
        return eventRepository.findAll();
    }

    /**
     * This function reads events from a list based on a given start time and returns a list of events
     * that have the same start time.
     * 
     * @param startTime A LocalTime object representing the start time of the events to be searched
     * for.
     * @return A list of events that have the same start time as the input parameter `startTime`.
     */

    public List<Event> readByTime(LocalTime startTime) {
        logger.info("Reading events by start time: {}", startTime);
        List<Event> events = readAllEvent();
        List<Event> sameTimeEvents = new ArrayList<>();
        for (Event event : events) {
            LocalTime eventStartTime = event.getStartTime();
            if (eventStartTime != null && eventStartTime.equals(startTime))
                sameTimeEvents.add(event);
        }
        if (sameTimeEvents.isEmpty()) {
            logger.error("Start time is not found: {}", startTime);
            throw new ResourceNotFound(String.valueOf(startTime), "Event is not Found in this time.", 404);
        }
        return sameTimeEvents;
    }

    /**
     * This Java function reads events by venue and returns a list of events that have the same venue
     * as the input parameter, or throws a ResourceNotFound exception if no events are found with that
     * venue.
     * 
     * @param venue a String representing the name of the venue where events are being searched for.
     * @return This method returns a list of events that are taking place in a specific venue.
     */

     public List<Event> readByVenue(String venue) {
        logger.info("Reading events by venue: {}", venue);
        List<Event> events = readAllEvent();
        List<Event> sameVenueEvents = new ArrayList<>();
        for (Event event : events) {
            if (event.getVenue() != null && event.getVenue().equals(venue)) {
                sameVenueEvents.add(event);
            }
        }
        if (sameVenueEvents.isEmpty()) {
            logger.error("Venue is not found: {}", venue);
            throw new ResourceNotFound(String.valueOf(venue), "Event is not Found in this venue.", 404);
        }
        return sameVenueEvents;
    }

    /**
     * This function reads events from a list by a specific date and returns a list of events that
     * match the date, or throws an exception if no events are found.
     * 
     * @param eventDate A LocalDate object representing the date for which events are to be searched.
     * @return A list of events that have the same date as the input parameter `eventDate`.
     */

    public List<Event> readByDate(LocalDate eventDate) {
        logger.info("Reading events by date: {}", eventDate);
        List<Event> events = readAllEvent();
        List<Event> sameDateEvents = new ArrayList<>();
        for (Event event : events) {
            LocalDate eventOccuringDate = event.getEventDate();
            if (eventOccuringDate != null && eventOccuringDate.equals(eventDate))
                sameDateEvents.add(event);
        }
        if (sameDateEvents.isEmpty()) {
            logger.error("Date is not found: {}", eventDate);
            throw new ResourceNotFound(String.valueOf(eventDate), "Event is not Found in this date.", 404);
        }
        return sameDateEvents;
    }

    /**
     * This function reads a list of events within a specified range of dates.
     * 
     * @param startDate A LocalDate object representing the start date of the range of dates to filter
     * events by.
     * @param endDate The end date of the range of dates to filter events by.
     * @return The method is returning a List of Event objects that fall within the range of dates
     * specified by the startDate and endDate parameters.
     */

     public List<Event> readByRangeOfDates(LocalDate startDate, LocalDate endDate) {
        logger.info("Reading events by range of dates: {} to {}", startDate, endDate);
        List<Event> events = readAllEvent();
        List<Event> filteredEvents = new ArrayList<>();
        for (Event event : events) {
            LocalDate eventDate = event.getEventDate();
            if (startDate != null && eventDate != null && eventDate.isEqual(startDate)) {
                filteredEvents.add(event);
            }
            if (startDate != null && endDate != null && eventDate != null && eventDate.isAfter(startDate) && eventDate.isBefore(endDate)) {
                filteredEvents.add(event);
            }
            if (endDate != null && eventDate != null && eventDate.isEqual(endDate)) {
                filteredEvents.add(event);
            }
        }
        return filteredEvents;
    }      

    /**
     * This Java function creates an Attendee object with details from an AttendeeDto object.
     * 
     * @param attendeeDetailsDto An object of type AttendeeDto that contains the details of an
     * attendee, such as their first name, last name, and email address.
     * @return An instance of the `Attendee` class with the `firstname`, `lastname`, and `emailAddress`
     * properties set based on the values provided in the `attendeeDetailsDto` parameter.
     */
    
    public Attendee attendeeDetails(AttendeeDto attendeeDetailsDto) {
        
        Attendee attendeeDetails = new Attendee();
        attendeeDetails.setFirstname(attendeeDetailsDto.getFirstname());
        attendeeDetails.setLastname(attendeeDetailsDto.getLastname());
        attendeeDetails.setEmailAddress(attendeeDetailsDto.getEmailAddress());
        return attendeeDetails;
    }

    /**
     * The function converts an EventDto object to an Event object in Java.
     * 
     * @param registeredEvent It is an object of type EventDto which contains the details of an event
     * such as event name, description, status, start time, end time, date, and venue. This method
     * converts the EventDto object to an Event object.
     * @return An instance of the `Event` class is being returned.
     */

    public Event convertEventDtoToEvent(EventDto registeredEvent) {

        Event event = new Event();
        event.setEventName(registeredEvent.getEventName());
        event.setEventDescription(registeredEvent.getEventDescription());
        event.setEventStatus(registeredEvent.getEventStatus());
        event.setStartTime(registeredEvent.getStartTime());
        event.setEndTime(registeredEvent.getEndTime());
        event.setEventDate(registeredEvent.getEventDate());
        event.setVenue(registeredEvent.getVenue());
        return event;
    }

    /**
     * This function checks if a given start time for an event is already booked or not.
     * 
     * @param startTime startTime is a LocalTime object representing the start time of an event. The
     * method isTimeAlreadyBooked checks if this start time is already booked by an existing event in
     * the event repository.
     * @return The method `isTimeAlreadyBooked` is returning a boolean value, which indicates whether
     * the given `startTime` parameter is already booked or not. The value is obtained by calling the
     * `existsByTime` method of the `eventRepository` object, which returns a boolean value based on
     * whether there is an event already booked at the given `startTime`.
     */

    private boolean isTimeAlreadyBooked(LocalTime startTime) {
        logger.info("Checking if time is already booked: {}", startTime);
        return eventRepository.existsByTime(startTime);
    }
    
    /**
     * This Java function checks if a venue is already booked for an event.
     * 
     * @param venue A string representing the name or location of a venue that needs to be checked if
     * it is already booked for an event. The method uses the eventRepository to check if there is
     * already an event booked at the specified venue. The method returns a boolean value indicating
     * whether the venue is already booked or not.
     * @return The method is returning a boolean value which indicates whether the venue is already
     * booked or not.
     */

    private boolean isVenueAlreadyBooked(String venue) {
        logger.info("Checking if venue is already booked: {}", venue);
        return eventRepository.existsByVenue(venue);
    }
    
    /**
     * This function checks if a given date is already booked for an event.
     * 
     * @param eventDate The date of an event that needs to be checked if it is already booked or not.
     * @return The method is returning a boolean value which indicates whether the given event date is
     * already booked or not. If the event date is already booked, the method will return true,
     * otherwise it will return false.
     */

    public boolean isDateAlreadyBooked(LocalDate eventDate) {
        logger.info("Checking if date is already booked: {}", eventDate);
        return eventRepository.existsByEventDate(eventDate);
    }

}
