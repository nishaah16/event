package com.example.event.controller;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.event.dto.EventDto;
import com.example.event.entity.Event;
import com.example.event.service.EventService;

@RestController
@RequestMapping("/api/event")
public class EventController {

    private static final Logger logger = LoggerFactory.getLogger(EventController.class);

    @Autowired
    private EventService eventService;   

    /**
     * This function creates an event for a specific attendee and returns the ID of the created event.
     * 
     * @param attendeeId The ID of the attendee who is creating the event.
     * @param eventsDto The parameter "eventsDto" is of type "EventDto", which is a custom data
     * transfer object (DTO) used to transfer data related to an event. It contains information such as
     * the event name, description, start and end time, location, and other details. This parameter is
     * used to create
     * @return A ResponseEntity object containing the ID of the created event and an HTTP status code
     * of OK (200).
     */

    @PostMapping("/{attendeeId}")
    public ResponseEntity<Long> createEvent(@PathVariable long attendeeId, @RequestBody EventDto eventsDto) {
        logger.info("Creating event: {}", eventsDto);
        long eventId = eventService.createEvent(attendeeId,eventsDto); 
        logger.debug("Event created with ID: {}", eventId);
        return new ResponseEntity<>(eventId,HttpStatus.OK);
    } 

    /**
     * This function deletes an event by its ID and returns a message with the HTTP status.
     * 
     * @param eventId eventId is a path variable of type long that represents the unique identifier of
     * an event that needs to be deleted.
     * @return A ResponseEntity object containing a message and an HTTP status code.
     */

    @DeleteMapping("/{eventId}")
    public ResponseEntity<String> deleteEventById(@PathVariable long eventId) {
        logger.info("Deleting event with ID: {}", eventId);
        String message = eventService.deleteEventById(eventId);
        logger.debug("Event ID deleted: {}", eventId);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    /**
     * This function updates an event by its ID and returns a message with the HTTP status code.
     * 
     * @param eventsDto An object of type EventDto that contains the updated information for the event.
     * @param eventId The ID of the event that needs to be updated. It is passed as a path variable in
     * the URL.
     * @return A ResponseEntity object containing a message and an HTTP status code.
     */

    @PutMapping("/{eventId}")
    public ResponseEntity<String> updateEventById(@RequestBody EventDto eventsDto,@PathVariable long eventId) {
        logger.info("Updating event with ID: {}", eventId);
        String message = eventService.updateEventById(eventsDto, eventId);
        logger.debug("Event ID updated: {}", eventId);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    /**
     * This function reads an event by its ID and returns a response entity with the event and a status
     * code.
     * 
     * @param eventId eventId is a path variable that represents the unique identifier of an event that
     * needs to be retrieved from the database. The method reads the event with the specified ID and
     * returns it as a response entity with HTTP status OK.
     * @return An HTTP response entity containing the event object with the specified ID and a status
     * code of 200 (OK).
     */

    @GetMapping("/{eventId}")
    public ResponseEntity<Object> readEventById(@PathVariable long eventId) {
        logger.info("Reading event with ID: {}", eventId);
        Event event = eventService.getEntityById(eventId);
        logger.debug("Event ID retrieved: {}", eventId);
        return new ResponseEntity<>(event, HttpStatus.OK);
    }

    /**
     * This function retrieves events with optional filters and returns a list of events.
     * 
     * @param startTime A LocalTime object representing the start time of an event.
     * @param venue The venue where the event is taking place.
     * @param eventDate Filters events by a specific date.
     * @param startDate The start date of a range of dates to filter events by.
     * @param endDate The end date parameter is used to filter events by a range of dates. It is the
     * end date of the range.
     * @return A ResponseEntity object containing a list of Event objects and an HTTP status code. The
     * list of events is filtered based on the optional parameters provided in the request, or all
     * events are returned if no parameters are provided.
     */

    public List<Event> getEventsList(LocalTime startTime,String venue,LocalDate eventDate,LocalDate startDate,LocalDate endDate)
    {
        List<Event> events=new ArrayList<>();
        if (startTime != null) {
            logger.info("Filtering events by start time: {}", startTime);
            events = eventService.readByTime(startTime);
        }
        if (eventDate != null) {
            logger.info("Filtering events by date: {}", eventDate);
            events = eventService.readByDate(eventDate);
        }
        if (startDate != null && endDate != null) {
            logger.info("Filtering events by range of dates: {} - {}", startDate, endDate);
            events = eventService.readByRangeOfDates(startDate, endDate);
        }
        if (venue != null) {
            logger.info("Filtering events by venue: {}", venue);
            events = eventService.readByVenue(venue);
        }
        if(startTime == null && eventDate == null && startDate == null && endDate == null && venue == null){
            logger.info("Reading all events");
            events = eventService.readAllEvent();
        }
        logger.debug("Event list is retieved: {}", events);
        return events;
    }
    
    @GetMapping
    public ResponseEntity<List<Event>> getEvents(  @RequestParam(required = false) LocalTime startTime,
                                                    @RequestParam(required = false) String venue,
                                                    @RequestParam(required = false) LocalDate eventDate,
                                                    @RequestParam(required = false) LocalDate startDate,
                                                    @RequestParam(required = false) LocalDate endDate ) {

        logger.info("Retrieving events with filters");
        List<Event> events = getEventsList(startTime,venue,eventDate,startDate,endDate);
        logger.debug("FIltered events: {}", events);
        return new ResponseEntity<>(events, HttpStatus.OK);
    }

}
