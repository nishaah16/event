package com.example.event.dto;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
public class AttendeeDto {

    private long attendeeId;
    @NotNull
    private String firstname;
    @NotNull
    private String lastname;
    @NotNull
    private String emailAddress;
    
    private EventDto registeredEvent;
    
}
