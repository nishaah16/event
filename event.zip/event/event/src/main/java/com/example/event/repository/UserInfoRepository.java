package com.example.event.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.example.event.entity.UserProfile;

@Repository
public interface UserInfoRepository extends JpaRepository <UserProfile, Long> {

    /**
     * The function finds a user profile by their username and returns an optional object.
     * 
     * @param username The username is a String parameter that represents the unique identifier of a
     * user's profile. It is used as a search criteria to find a user's profile in a database or other
     * data source. The method returns an Optional<UserProfile> object, which may or may not contain a
     * UserProfile instance depending on whether
     * @return The method is returning an Optional object that contains a UserProfile object if a user
     * with the specified username is found, or an empty Optional if no user is found.
     */

    Optional<UserProfile> findByUsername(String username);

    /**
     * Deletes an attendee from the database based on the provided username.
     * @param username the username of the attendee to be deleted
     */
    
}