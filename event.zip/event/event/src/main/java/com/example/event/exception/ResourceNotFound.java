package com.example.event.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class ResourceNotFound extends RuntimeException{
    
    private final String description;
    private final int statusCode;

    // This is a constructor for the `ResourceNotFound` class that takes in three parameters:
    // `message`, `description`, and `statusCode`.
    
    public ResourceNotFound(String message, String description, int statusCode) {
        super(message);
        this.description = description;
        this.statusCode = statusCode;
    }

    public String getDescription() {
        return description;
    }

    public int getStatusCode() {
        return statusCode;
    }
}

