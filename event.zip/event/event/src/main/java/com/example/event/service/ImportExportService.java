package com.example.event.service;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.example.event.dto.AttendeeDto;
import com.example.event.dto.EventDto;
import com.example.event.entity.Attendee;
import com.example.event.entity.Event;
import com.example.event.entity.EventStatus;
import com.example.event.exception.BadRequestException;
import com.example.event.exception.ResourceNotFound;
import com.example.event.repository.AttendeeRepository;
import com.example.event.repository.EventRepository;
import com.itextpdf.text.Document;
import com.itextpdf.text.DocumentException;
import com.itextpdf.text.Paragraph;
import com.itextpdf.text.pdf.PdfPCell;
import com.itextpdf.text.pdf.PdfPTable;
import com.itextpdf.text.pdf.PdfWriter;

@Service
public class ImportExportService {

    @Autowired
    private EventRepository eventRepository;

    @Autowired
    private AttendeeRepository attendeeRepository;

    private static final Logger logger = LoggerFactory.getLogger(ImportExportService.class);

    /**
    Uploads attendee information from a file and creates a list of Attendee objects.
    @param file The file containing attendee information.
    @return A list of Attendee objects created from the file.
    @throws IOException If an I/O error occurs while reading the file.
    @throws BadRequestException If the file name or format is invalid.
    */

    public List<Attendee> uploadAttendee(MultipartFile file) throws IOException {
        logger.info("Creating attendees from file");
        List<AttendeeDto> attendeesDto;
        String fileName = file.getOriginalFilename();

        if (fileName.endsWith(".csv")){
            logger.debug("Reading data from csv file");
            attendeesDto = readAttendeeFromCsv(file);
        }
        else if (fileName.endsWith(".xlsx")){
            logger.debug("Reading data from excel file");
            attendeesDto = readAttendeeFromExcel(file);
        }
        else{
            logger.error("Bad request");
            throw new BadRequestException("Invalid format","Provide valid file format",400);
        }

        List<Attendee> attendeeList = new ArrayList<>();
        for (AttendeeDto attendeeDto : attendeesDto) {
            Attendee attendee = createAttendee(attendeeDto);
            attendeeList.add(attendee);
        }
        logger.info("Attendees created successfully");
        return attendeeList;
    }

    /**
    Creates an Attendee object from the provided AttendeeDto object.
    @param attendeeDto The AttendeeDto object containing attendee details.
    @return The created Attendee object.
    */

    private Attendee createAttendee(AttendeeDto attendeeDto) {
        logger.debug("Creating attendee details: {}", attendeeDto.getAttendeeId());
        Attendee attendee = new Attendee();
            attendee.setFirstname(attendeeDto.getFirstname());
            attendee.setLastname(attendeeDto.getLastname());
            attendee.setEmailAddress(attendeeDto.getEmailAddress());
        Attendee createdAttendee = attendeeRepository.save(attendee);
        logger.debug("Attendee created: {}", createdAttendee.getAttendeeId());
        return createdAttendee;
    }

    /**
    Reads attendee information from a CSV file and returns a list of AttendeeDto objects.
    @param file The CSV file to read.
    @return A list of AttendeeDto objects representing the attendee information.
    @throws IOException If an I/O error occurs while reading the file.
    */

    private List<AttendeeDto> readAttendeeFromCsv(MultipartFile file) throws IOException {
        logger.info("Reading attendees from CSV file");
        List<AttendeeDto> attendeeDtos = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length >= 3) {
                    String firstName = fields[0].replace("\"", "").trim();
                    String lastName = fields[1].replace("\"", "").trim();
                    String emailAddress = fields[2].replace("\"", "").trim();
                    AttendeeDto attendeeDto = new AttendeeDto();
                        attendeeDto.setFirstname(firstName);
                        attendeeDto.setLastname(lastName);
                        attendeeDto.setEmailAddress(emailAddress);
                    attendeeDtos.add(attendeeDto);
                }
            }
        }
        return attendeeDtos;
    }

    /**
    Reads attendee information from an Excel file and returns a list of AttendeeDto objects.
    @param file The Excel file to read.
    @return A list of AttendeeDto objects representing the attendee information.
    @throws IOException If an I/O error occurs while reading the file.
    */

    private List<AttendeeDto> readAttendeeFromExcel(MultipartFile file) throws IOException {
        logger.info("Reading attendees from Excel file");
        try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            List<AttendeeDto> attendeeDtos = new ArrayList<>();
            for (Row row : sheet) {
                AttendeeDto attendeeDto = new AttendeeDto();
                String firstName = getCellValueAsString(row.getCell(0));
                String lastName = getCellValueAsString(row.getCell(1));
                String emailAddress = getCellValueAsString(row.getCell(2));
                    attendeeDto.setFirstname(firstName);
                    attendeeDto.setLastname(lastName);
                    attendeeDto.setEmailAddress(emailAddress);
                attendeeDtos.add(attendeeDto);
            }
            return attendeeDtos;
        }
    }

    /**
    Retrieves the cell value as a string from the given Cell object.
    If the cell is null, an empty string is returned.
    @param cell The Cell object to retrieve the value from.
    @return The cell value as a string.
    */

    private String getCellValueAsString(Cell cell) {
        if (cell == null) {
            logger.warn("Data is null");
            return "";
        }
        switch (cell.getCellType()) {
            case STRING:
                return cell.getStringCellValue().trim();
            default:
                logger.warn("Data is null");
                return "";
        }
    }

    /**
    Uploads event details for a specific attendee from a file.
    Creates and saves an Event object based on the file content.
    @param attendeeId The ID of the attendee for whom the event details are being uploaded.
    @param file The file containing the event details.
    @return The created Event object.
    @throws IOException If an I/O error occurs while reading the file.
    @throws ResourceNotFound If the attendee with the given ID is not found.
    @throws BadRequestException If the file name or format is invalid.
    */

    public Event uploadEvent(long attendeeId, MultipartFile file) throws IOException {
        logger.info("Creating event details for attendee id: {}", attendeeId);
        Attendee attendee = attendeeRepository.findById(attendeeId).orElseThrow(() -> {
            logger.warn("Attendee is not found: {}", attendeeId);
            return new ResourceNotFound(String.valueOf(attendeeId), "Attendee is not Found.", 404);
        });
        logger.info("Creating event details from file");
        EventDto eventDto;
        String fileName = file.getOriginalFilename();

        if (fileName.endsWith(".csv")){
            logger.debug("Reading data from csv file");
            eventDto = readEventFromCsv(file);
        }
        else if (fileName.endsWith(".xlsx")){
            logger.debug("Reading data from excel file");
            eventDto = readEventFromExcel(file);
        }
        else{
            logger.error("Bad request");
            throw new BadRequestException("Invalid format","Provide valid file format",400);
        }
        Event event = new Event();
        event.setEventName(eventDto.getEventName());
        event.setEventDescription(eventDto.getEventDescription());
        event.setEventStatus(eventDto.getEventStatus());
        event.setStartTime(eventDto.getStartTime());
        event.setEndTime(eventDto.getEndTime());
        event.setEventDate(eventDto.getEventDate());
        event.setVenue(eventDto.getVenue());
        
        eventRepository.save(event);
        attendee.setRegisteredEvent(event); 
        attendeeRepository.save(attendee);
        
        logger.debug("Events created successfully");
        return event;
    }

    /**
    Reads event details from an Excel file and returns an EventDto object.
    @param file The Excel file to read the event details from.
    @return An EventDto object representing the event details.
    @throws IOException If an I/O error occurs while reading the file.
    */

    private EventDto readEventFromExcel(MultipartFile file) throws IOException {
        logger.debug("Reading event from Excel file");
        try (Workbook workbook = WorkbookFactory.create(file.getInputStream())) {
            Sheet sheet = workbook.getSheetAt(0);
            EventDto eventDto = new EventDto(); 
            Row firstRow = sheet.getRow(0); 
            if (firstRow != null) {
                eventDto.setEventName(getCellValueAsString(firstRow.getCell(0)));
                eventDto.setEventDescription(getCellValueAsString(firstRow.getCell(1)));
                eventDto.setEventStatus(EventStatus.valueOf(getCellValueAsString(firstRow.getCell(2))));
                eventDto.setStartTime(LocalTime.parse(getCellValueAsString(firstRow.getCell(3)), DateTimeFormatter.ofPattern("HH:mm")));
                eventDto.setEndTime(LocalTime.parse(getCellValueAsString(firstRow.getCell(4)), DateTimeFormatter.ofPattern("HH:mm")));
                eventDto.setEventDate(LocalDate.parse(getCellValueAsString(firstRow.getCell(5)), DateTimeFormatter.ofPattern("dd-MM-yyyy")));
                eventDto.setVenue(getCellValueAsString(firstRow.getCell(6)));
            }
            return eventDto;
        }
    }

    /**
    Reads event details from a CSV file and returns an EventDto object.
    @param file The CSV file to read the event details from.
    @return An EventDto object representing the event details.
    @throws IOException If an I/O error occurs while reading the file.
    */

    private EventDto readEventFromCsv(MultipartFile file) throws IOException {
        logger.debug("Reading event from CSV file");
        EventDto eventDto=new EventDto();
        try (BufferedReader reader = new BufferedReader(new InputStreamReader(file.getInputStream()))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length >= 7) {
                    String eventName = fields[0].replace("\"","").trim();
                    String eventDescription = fields[1].replace("\"","").trim();
                    EventStatus status = EventStatus.valueOf(fields[2].replace("\"","").trim());
                    LocalTime startTime = LocalTime.parse(fields[3].replace("\"","").trim(), DateTimeFormatter.ofPattern("HH:mm"));
                    LocalTime endTime = LocalTime.parse(fields[4].replace("\"","").trim(), DateTimeFormatter.ofPattern("HH:mm"));
                    LocalDate eventDate = LocalDate.parse(fields[5].replace("\"","").trim(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));
                    String venue = fields[6].replace("\"","").trim();
                    eventDto.setEventName(eventName);
                    eventDto.setEventDescription(eventDescription);
                    eventDto.setEventStatus(status);
                    eventDto.setStartTime(startTime);
                    eventDto.setEndTime(endTime);
                    eventDto.setEventDate(eventDate);
                    eventDto.setVenue(venue);
                }
            }
        }
        return eventDto;
    }

    /**
    Exports the details of a list of events to a PDF document.
    @param events The list of events to export.
    @return The byte array representing the exported PDF document.
    @throws DocumentException If an error occurs while creating the PDF document.
    */

    public byte[] exportEvent(List<Event> events) throws DocumentException {
        logger.info("Exporting event details to PDF");
        ByteArrayOutputStream outputStream = new ByteArrayOutputStream();
        Document document = new Document();
        PdfWriter writer = PdfWriter.getInstance(document, outputStream);
        PageHeaderFooter eventPageHeaderFooter = new PageHeaderFooter();
        writer.setPageEvent(eventPageHeaderFooter);
        document.open();
        PdfPTable table = new PdfPTable(8);
        table.setWidthPercentage(100);
        addTableHeader(table);
        for (Event event : events) {
            addTableRow(table, event);
        }
        document.add(table);
        document.close();
        logger.info("Event items exported to PDF successfully");
        return outputStream.toByteArray();
    }
    
    /**
    Adds the header row to the PDF table.
    @param table The PdfPTable object to add the header row to.
    */

    private void addTableHeader(PdfPTable table) {
        
        PdfPCell cell;

        cell = new PdfPCell(new Paragraph("Event Id"));
        table.addCell(cell);

        cell = new PdfPCell(new Paragraph("Event Name"));
        table.addCell(cell);

        cell = new PdfPCell(new Paragraph("Event Description"));
        table.addCell(cell);

        cell = new PdfPCell(new Paragraph("Event Status"));
        table.addCell(cell);

        cell = new PdfPCell(new Paragraph("Starting Time"));
        table.addCell(cell);

        cell = new PdfPCell(new Paragraph("Ending Time"));
        table.addCell(cell);

        cell = new PdfPCell(new Paragraph("Event Date"));
        table.addCell(cell);

        cell = new PdfPCell(new Paragraph("Event Venue"));
        table.addCell(cell);
    }

    /**
    Adds a row to the PDF table with the event details.
    @param table The PdfPTable object to add the row to.
    @param event The Event object containing the event details.
    */

    private void addTableRow(PdfPTable table, Event event) {
        logger.debug("Adding event items to PDF: {}", event.getEventId());
        table.addCell(String.valueOf(event.getEventId()));
        table.addCell(event.getEventName());
        table.addCell(event.getEventDescription());
        table.addCell(event.getEventStatus().name());
        table.addCell(event.getStartTime().toString());
        table.addCell(event.getEndTime().toString());
        table.addCell(event.getEventDate().toString());
        table.addCell(event.getVenue());
    }
}

