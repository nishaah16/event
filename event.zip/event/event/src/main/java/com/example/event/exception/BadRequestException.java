package com.example.event.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class BadRequestException extends RuntimeException{
    
    private final String description;
    private final int statusCode;

    // This is a constructor for the `BadRequestException` class that takes in three parameters:
    // `message`, `description`, and `statusCode`.
    
    public BadRequestException(String message, String description, int statusCode) {
        super(message);
        this.description = description;
        this.statusCode = statusCode;
    }

    public String getDescription() {
        return description;
    }

    public int getStatusCode() {
        return statusCode;
    }
}
