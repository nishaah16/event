package com.example.event.service;

import com.itextpdf.text.Document;
import com.itextpdf.text.Element;
import com.itextpdf.text.Font;
import com.itextpdf.text.Phrase;
import com.itextpdf.text.pdf.ColumnText;
import com.itextpdf.text.pdf.PdfContentByte;
import com.itextpdf.text.pdf.PdfPageEventHelper;
import com.itextpdf.text.pdf.PdfWriter;

public class PageHeaderFooter extends PdfPageEventHelper {
    
    private Font headerFont;
    private Font footerFont;

    /**
    Constructs a new PageHeaderFooter object.
    */

    public PageHeaderFooter() {
        
        headerFont = new Font(Font.FontFamily.HELVETICA, 12, Font.BOLD);
        footerFont = new Font(Font.FontFamily.HELVETICA, 10, Font.NORMAL);
    }

    /**
    Overrides the onStartPage method from the PdfPageEventHelper class to add a header title to each page of a PDF document.
    @param writer The PdfWriter object used to write the PDF document.
    @param document The Document object representing the PDF document.
    */

    @Override
    public void onStartPage(PdfWriter writer, Document document) {
        
        Phrase title = new Phrase("Event Details", headerFont);
        float x = (document.right() + document.left()) / 2;
        float y = document.top() + 10;
        try {
            PdfContentByte canvas = writer.getDirectContent();
            ColumnText.showTextAligned(canvas, Element.ALIGN_CENTER, title, x, y, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
    Overrides the onEndPage method from the PdfPageEventHelper class to add a page number to the footer of a PDF document.
    @param writer The PdfWriter object used to write the PDF document.
    @param document The Document object representing the PDF document.
    */

    @Override
    public void onEndPage(PdfWriter writer, Document document) {
        // Add page number to the footer
        int pageNumber = writer.getPageNumber();
        Phrase footer = new Phrase("Page " + pageNumber, footerFont);
        float x = (document.right() + document.left()) / 2;
        float y = document.bottomMargin() - 10;
        try {
            PdfContentByte canvas = writer.getDirectContent();
            ColumnText.showTextAligned(canvas, Element.ALIGN_CENTER, footer, x, y, 0);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}

