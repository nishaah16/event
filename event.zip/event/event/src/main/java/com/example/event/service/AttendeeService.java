package com.example.event.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.event.dto.AttendeeDto;
import com.example.event.entity.Attendee;
import com.example.event.exception.BadRequestException;
import com.example.event.exception.ResourceNotFound;
import com.example.event.repository.AttendeeRepository;

@Service
public class AttendeeService {

    @Autowired
    private AttendeeRepository attendeeRepository;

    @Autowired
    private EventService eventService;

    private static final Logger logger = LoggerFactory.getLogger(AttendeeService.class);

    /**
     * This function creates an attendee and saves their details to a repository, but throws a
     * BadRequestException if any required fields are missing.
     * 
     * @param attendeeDetailsDto an object of type AttendeeDto that contains the details of the
     * attendee to be created, such as their first name, last name, and email address.
     * @return The method is returning a long value which represents the ID of the created attendee.
     */
    
    public long createAttendee(AttendeeDto attendeeDetailsDto) {

        if (attendeeDetailsDto.getFirstname() == null || attendeeDetailsDto.getLastname() == null || attendeeDetailsDto.getEmailAddress() == null) {
            logger.error("Invalid request: All fields must be provided");
            throw new BadRequestException("Invalid request", "All fields must be provided",400);
        }
        else{
            Attendee attendeeDetails = eventService.attendeeDetails(attendeeDetailsDto);
            logger.debug("Creating attendee: {}", attendeeDetails);
            attendeeRepository.save(attendeeDetails);
            return attendeeDetails.getAttendeeId();
        }
    }

    /**
     * This Java function deletes an attendee from a repository by their ID and returns a success
     * message.
     * 
     * @param attendeeId a long integer representing the unique identifier of the attendee that needs
     * to be deleted from the database.
     * @return The method is returning a String message "Attendee Deleted Successfully" after deleting
     * the attendee with the given ID from the attendee repository.
     */

    public String deleteAttendeeById(long attendeeId) {
        logger.info("Deleting attendee with ID: {}", attendeeId);
        Attendee attendeeDetail = attendeeRepository.findById(attendeeId).orElseThrow(() -> {
            logger.warn("Attendee is not found: {}", attendeeId);
            return new ResourceNotFound(String.valueOf(attendeeId), "Attendee is not Found.", 404);
        });
        attendeeRepository.delete(attendeeDetail);
        return "Attendee Deleted Successfully";
    }

    /**
     * This function updates an attendee's details by their ID and returns a success message.
     * 
     * @param attendeeDetailsDto An object of type AttendeeDto that contains the updated details of the
     * attendee.
     * @param attendeeId The ID of the attendee that needs to be updated.
     * @return The method is returning a String message "Attendee Updated Successfully" after updating
     * the attendee details in the database.
     */

    public String updateAttendeeById(AttendeeDto attendeeDetailsDto, long attendeeId) {
        logger.info("Updating attendee with ID: {}", attendeeId);
        Attendee attendeeDetail = attendeeRepository.findById(attendeeId).orElseThrow(() -> {
            logger.warn("Attendee is not found: {}", attendeeId);
            return new ResourceNotFound(String.valueOf(attendeeId), "Attendee is not Found.", 404);
        });
        if (attendeeDetailsDto.getFirstname() == null || attendeeDetailsDto.getLastname() == null || attendeeDetailsDto.getEmailAddress() == null) {
            logger.error("Invalid request: All fields must be provided");
            throw new BadRequestException("Invalid request", "All fields must be provided", 400);
        }
        attendeeDetail.setFirstname(attendeeDetailsDto.getFirstname());
        attendeeDetail.setLastname(attendeeDetailsDto.getLastname());
        attendeeDetail.setEmailAddress(attendeeDetailsDto.getEmailAddress());
        attendeeRepository.save(attendeeDetail);
        return "Attendee Updated Successfully";
    }
}
