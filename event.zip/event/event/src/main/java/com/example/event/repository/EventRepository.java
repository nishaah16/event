package com.example.event.repository;

import java.time.LocalDate;
import java.time.LocalTime;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.example.event.entity.Event;

@Repository
public interface EventRepository extends JpaRepository<Event,Long> {

    /**
     * This function checks if an event exists on a specific date.
     * 
     * @param eventDate The parameter "eventDate" is a LocalDate object representing the date of an
     * event. This query checks if there exists any event in the database with the same eventDate as
     * the one provided. The query returns a boolean value indicating whether such an event exists or
     * not.
     * @return A boolean value is being returned, indicating whether there exists an event with the
     * specified event date or not. If there is at least one event with the specified date, the method
     * will return true, otherwise it will return false.
     */

    @Query("SELECT COUNT(e) > 0 FROM Event e WHERE e.eventDate = :eventDate")
    boolean existsByEventDate(LocalDate eventDate);

   /**
    * This function checks if there exists an event with a given venue.
    * 
    * @param venue The "venue" parameter is a variable that represents the venue of an event. It is
    * used in the query to check if there exists any event with the given venue.
    * @return A boolean value is being returned, indicating whether there is at least one event
    * associated with the specified venue.
    */

    @Query("SELECT COUNT(e) > 0 FROM Event e WHERE e.venue = :venue")
    boolean existsByVenue(String venue);

    /**
     * This function checks if an event exists with a specific start time.
     * 
     * @param startTime startTime is a parameter of type LocalTime which is used in the query to check
     * if there exists any Event with the same start time as the given startTime parameter. The query
     * returns a boolean value indicating whether such an Event exists or not.
     * @return A boolean value is being returned, indicating whether there exists an event with the
     * specified start time or not. If there is at least one event with the specified start time, the
     * method will return true, otherwise it will return false.
     */

    @Query("SELECT COUNT(e) > 0 FROM Event e WHERE e.startTime = :startTime")
    boolean existsByTime(LocalTime startTime);

    /**
     * The function findByEventId(long eventId) searches and returns an event object based on its
     * unique eventId.
     * 
     * @param eventId The eventId parameter is a unique identifier for an event. It is used to search
     * for a specific event in a database or collection of events. The method findByEventId(long
     * eventId) takes in this parameter and returns the event object that matches the given eventId.
     * @return The method `findByEventId` is returning an `Event` object that matches the specified
     * `eventId`.
     */
    
    Event findByEventId(long eventId);


}