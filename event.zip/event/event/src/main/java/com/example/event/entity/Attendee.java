package com.example.event.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.Table;
import lombok.NoArgsConstructor;

@NoArgsConstructor
@Entity
@Table(name = "attendee")
public class Attendee extends BaseModel{

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "attendeeId")
    private long attendeeId;
    private String firstname;
    private String lastname;
    private String emailAddress;
    @ManyToOne
    private Event registeredEvent;

    public void setFirstname(String firstname) {
        this.firstname = firstname;
    }
    public void setLastname(String lastname) {
        this.lastname = lastname;
    }
    public void setEmailAddress(String emailAddress) {
        this.emailAddress = emailAddress;
    }
    public void setRegisteredEvent(Event registeredEvent) {
        this.registeredEvent = registeredEvent;
    }
    public long getAttendeeId() {
        return attendeeId;
    }
    public void setAttendeeId(long attendeeId) {
        this.attendeeId = attendeeId;
    }
    
    

}
