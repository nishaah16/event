package com.example.event.entity;

import org.springframework.security.core.context.SecurityContextHolder;

import java.util.Date;

import org.springframework.security.core.Authentication;


import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import jakarta.persistence.PrePersist;
import jakarta.persistence.PreUpdate;
import jakarta.persistence.Temporal;
import jakarta.persistence.TemporalType;

@MappedSuperclass
public abstract class BaseModel {

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "createdOn")
    protected Date createdOn;
    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "updatedOn")
    protected Date updatedOn;
    @Column(name = "createdBy")
    protected String createdBy;
    @Column(name = "updatedBy")
    protected String updatedBy;



    @PrePersist
    protected void onCreate() {
        createdOn = new Date();
        createdBy = getLoggedInUserName();
    }

    @PreUpdate
    protected void onUpdate() {
        updatedOn = new Date();
        updatedBy = getLoggedInUserName();
    }

    private String getLoggedInUserName() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.isAuthenticated() ? authentication.getName() : "";

    }
}

