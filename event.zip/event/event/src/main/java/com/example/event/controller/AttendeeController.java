package com.example.event.controller;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.event.dto.AttendeeDto;
import com.example.event.service.AttendeeService;

@RestController
@RequestMapping("/api/attendee")
public class AttendeeController {

    private static final Logger logger = LoggerFactory.getLogger(AttendeeController.class);

    @Autowired
    private AttendeeService attendeeService;

    /**
     * This Java function creates an attendee and returns their ID as a ResponseEntity.
     * 
     * @param attendeeDetailsDto It is a parameter of type AttendeeDto which contains the details of
     * the attendee being created. It is passed as a request body in the POST request.
     * @return A ResponseEntity object containing the ID of the created attendee and an HTTP status
     * code of OK (200).
     */

    @PostMapping
    public ResponseEntity<Long> createAttendee(@RequestBody AttendeeDto attendeeDetailsDto) {
        logger.info("Creating attendee details: {}", attendeeDetailsDto);
        long attendeeId = attendeeService.createAttendee(attendeeDetailsDto); 
        logger.debug("Attendee created with ID: {}", attendeeId);
        return new ResponseEntity<>(attendeeId,HttpStatus.OK);
    }  
    
    /**
     * This function deletes an attendee by their ID and returns a message with the status code.
     * 
     * @param attendeeId The ID of the attendee that needs to be deleted. It is passed as a path
     * variable in the URL.
     * @return A ResponseEntity object containing a message and an HTTP status code.
     */

    @DeleteMapping("/{attendeeId}")
    public ResponseEntity<String> deleteAttendeeById(@PathVariable long attendeeId) {
        logger.info("Deleting attendee with ID: {}", attendeeId);
        String message = attendeeService.deleteAttendeeById(attendeeId);
        logger.debug("Attendee ID deleted: {}", attendeeId);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

    /**
     * This function updates an attendee's details by their ID.
     * 
     * @param attendeeDetailsDto This is an object of type AttendeeDto that contains the updated
     * details of the attendee that needs to be updated in the database.
     * @param attendeeId The ID of the attendee that needs to be updated. It is passed as a path
     * variable in the URL of the API endpoint.
     * @return A ResponseEntity object containing a message and an HTTP status code.
     */
    
    @PutMapping("/{attendeeId}")
    public ResponseEntity<String> updateAttendeeById(@RequestBody AttendeeDto attendeeDetailsDto,@PathVariable long attendeeId) {
        logger.info("Updating attendee with ID: {}", attendeeId);
        String message = attendeeService.updateAttendeeById(attendeeDetailsDto, attendeeId);
        logger.debug("Attendee ID updated: {}", attendeeId);
        return new ResponseEntity<>(message, HttpStatus.OK);
    }

}