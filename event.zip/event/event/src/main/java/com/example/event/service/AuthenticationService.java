package com.example.event.service;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.example.event.configuration.UserInfoUserDetails;
import com.example.event.entity.UserProfile;
import com.example.event.exception.BadRequestException;
import com.example.event.exception.ResourceNotFound;
import com.example.event.repository.UserInfoRepository;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Service
public class AuthenticationService implements UserDetailsService{

    private static final Logger logger = LoggerFactory.getLogger(AuthenticationService.class);

    @Autowired
    private UserInfoRepository userInfoRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;
    
    /**
     * This function loads user details by username from a repository and returns a UserDetails object
     * or throws a ResourceNotFound exception if the username is not found.
     * 
     * @param username The username of the user being loaded.
     * @return The method is returning an instance of UserDetails, which is either created from a
     * UserProfile object retrieved from the userInfoRepository or throwing a ResourceNotFound
     * exception if the user is not found in the repository.
     */

    @Override
    public UserDetails loadUserByUsername(String username) {
        logger.info("Loading user by username: {}", username);
        Optional<UserProfile> userInfo = userInfoRepository.findByUsername(username);
        return userInfo.map(UserInfoUserDetails::new).orElseThrow(() -> {
            logger.warn("Username not found: {}", username);
            return new ResourceNotFound(username, "User not Found.", 404);
        });
    }

    /**
     * The function registers a user by saving their profile information and returning a success
     * message in a map.
     * 
     * @param userProfile an object of type UserProfile that contains information about the user being
     * registered, such as their username, password, and role.
     * @return A Map<String, String> containing a message, description, and status code.
     */
    
    public Map<String, String> registerUser(UserProfile userProfile) {

        if (userProfile.getUsername() == null || userProfile.getPassword() == null || userProfile.getRole() == null) {
            logger.error("Invalid request: All fields must be provided");
            throw new BadRequestException("Invalid request", "All fields must be provided",400);
        }
        else {
            logger.info("Registering user: {}", userProfile.getUsername());
            userProfile.setPassword(passwordEncoder.encode(userProfile.getPassword()));
            userInfoRepository.save(userProfile);
            logger.debug("User registered successfully: {}", userProfile.getUsername());
            Map<String, String> response = new HashMap<>();
            response.put("message", "User added to the system");
            response.put("description", "Successful");
            response.put("status", "200");
            return response;
        }
    }
}
    

