package com.example.event.controller;

import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.example.event.entity.Event;
import com.example.event.service.ImportExportService;
import com.itextpdf.text.DocumentException;


@RestController
@RequestMapping("/api")
public class ImportExportController {

    private static final Logger logger = LoggerFactory.getLogger(ImportExportController.class);

    @Autowired
    private ImportExportService importExportService;   

    @Autowired
    private EventController eventController; 

    /**
     * This function uploads attendee details from a file in a POST request and returns a success
     * message.
     * 
     * @param file The "file" parameter is a MultipartFile object that represents the file being
     * uploaded in the HTTP request. It is annotated with @RequestParam to indicate that it is a
     * request parameter and should be extracted from the request.
     * @return A ResponseEntity object containing a success message and an HTTP status code of 200
     * (OK).
     */

    @PostMapping("/upload/attendee")
    public ResponseEntity<String> uploadAttendee(@RequestParam("file") MultipartFile file) throws IOException{
        logger.info("Uploading attendee details");
        importExportService.uploadAttendee(file);
        return new ResponseEntity<>("Attendee details uploaded successfully" , HttpStatus.OK);
    }

    /**
     * This function uploads event details with an attendee ID and a file in a POST request.
     * 
     * @param attendeeId A long integer representing the ID of the attendee associated with the event
     * being uploaded.
     * @param file The "file" parameter is of type MultipartFile and represents the file that is being
     * uploaded as part of the request. It is used to transfer binary data, such as images, videos, or
     * documents, from the client to the server.
     * @return A ResponseEntity object containing a String message "Event details uploaded
     * successfully" and an HTTP status code of 200 (OK).
     */

    @PostMapping("/upload/event")
    public ResponseEntity<String> uploadEvent(@RequestParam("attendeeId") long attendeeId,@RequestParam("file") MultipartFile file) throws IOException{
        logger.info("Uploading event Details");
        importExportService.uploadEvent(attendeeId,file);
        return new ResponseEntity<>("Event details uploaded successfully" , HttpStatus.OK);
    }

    /**
     * This function exports events based on various filters and returns a PDF file containing the
     * results.
     * 
     * @param startTime A LocalTime object representing the start time of an event.
     * @param venue The venue where the event is taking place.
     * @param eventDate A LocalDate parameter used to filter events by a specific date.
     * @param startDate The start date of the range of dates to filter events by.
     * @param endDate The end date parameter is used to filter events by a range of dates. It is an
     * optional parameter that specifies the end date of the range.
     * @return A ResponseEntity object containing a byte array of PDF contents, HttpHeaders with
     * content type set to APPLICATION_PDF, and a content disposition with file name
     * "event_reports.pdf". The HTTP status code is OK (200) if the export is successful, or
     * INTERNAL_SERVER_ERROR (500) if there is an error during the export process.
     */
    
    @GetMapping("/event/pdf")
    public ResponseEntity<byte[]> exportEvent( @RequestParam(required = false) LocalTime startTime,
    @RequestParam(required = false) String venue,
    @RequestParam(required = false) LocalDate eventDate,
    @RequestParam(required = false) LocalDate startDate,
    @RequestParam(required = false) LocalDate endDate ) {
        try {
            logger.info("Exporting events:");
            List<Event> events = eventController.getEventsList(startTime, venue, eventDate, startDate, endDate);
            logger.debug("Retrieved filtered events:");
            byte[] pdfContents = importExportService.exportEvent(events);
            HttpHeaders headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_PDF);
            headers.setContentDispositionFormData("file", "event_reports.pdf");
            return new ResponseEntity<>(pdfContents, headers, HttpStatus.OK);
        } 
        catch (DocumentException e) {
            logger.error("Error occurred while exporting search results to PDF: {}", e.getMessage());
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }

}
