package com.example.event.filter;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import com.example.event.service.AuthenticationService;
import com.example.event.service.JwtService;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@Component
public class SecurityFilter extends OncePerRequestFilter{

    @Autowired
    private JwtService jwtService;

    @Autowired
    private AuthenticationService authService;

    public SecurityFilter(JwtService jwtService,
            AuthenticationService authenticationService) {
        this.jwtService = jwtService;
        this.authService = authenticationService;
    }

    /**
     * This function extracts a JWT token from the Authorization header of an HTTP request, validates
     * it, and sets the authentication details in the SecurityContextHolder.
     * 
     * @param request An object representing the HTTP request made by the client.
     * @param response The HttpServletResponse object represents the response that will be sent back to
     * the client after the request has been processed. It contains methods for setting response
     * headers, writing response content, and setting the response status code.
     * @param filterChain The FilterChain is an object that represents a chain of filters that will be
     * applied to a request in a web application. It is responsible for passing the request and
     * response objects to the next filter in the chain until the request is processed by the
     * appropriate servlet.
     */
    
    @Override
    public void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        String authHeader = request.getHeader("Authorization");
        String token = null;
        String username = null;
        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            token = authHeader.substring(7);
            username = jwtService.extractUsername(token);
        }

        if (username != null && SecurityContextHolder.getContext().getAuthentication() == null) {
            UserDetails userDetails = authService.loadUserByUsername(username);
            if (Boolean.TRUE.equals(jwtService.validateToken(token, userDetails))) {
                List<GrantedAuthority> authorities = new ArrayList<>(userDetails.getAuthorities());
                authorities.addAll(userDetails.getAuthorities());
                UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails,
                        null, authorities);
                authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
                SecurityContextHolder.getContext().setAuthentication(authToken);
            }
        }

        filterChain.doFilter(request, response);

    }
    
}
