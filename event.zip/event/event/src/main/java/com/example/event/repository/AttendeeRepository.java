package com.example.event.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.event.entity.Attendee;
import com.example.event.entity.Event;


@Repository
public interface AttendeeRepository extends JpaRepository<Attendee,Long> {

    /**
     * This function returns a list of attendees who have registered for a specific event identified by
     * its eventId.
     * 
     * @param eventId The eventId parameter is a long data type that represents the unique identifier
     * of an event. This method is used to find all the attendees who have registered for a specific
     * event identified by the eventId. The method returns a list of Attendee objects who have
     * registered for the event.
     * @return The method is returning a list of Attendee objects who have registered for an event with
     * the specified eventId.
     */
    
    List<Attendee> findByRegisteredEvent_EventId(long eventId);

    List<Attendee> findByRegisteredEvent(Event event);

}
