package com.example.event.controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.event.dto.UserProfileDto;
import com.example.event.entity.UserProfile;
import com.example.event.service.AuthenticationService;
import com.example.event.service.JwtService;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@RestController
@RequestMapping("/api/auth")
public class AuthenticationController {

    private static final Logger logger = LoggerFactory.getLogger(AuthenticationController.class);

    @Autowired
    private AuthenticationService authService;

    @Autowired
    private AuthenticationManager authenticationManager;
    
    @Autowired
    private JwtService jwtService;

    /**
     * This function registers a user by accepting user profile information and returning a map of
     * strings.
     * 
     * @param userProfile The parameter "userProfile" is an object of the class "UserProfile" that is
     * received in the request body of a POST request to the "/signup" endpoint. It contains the user's
     * registration information such as username, password, email, etc.
     * @return A Map object containing key-value pairs of String type. The keys are of String type and
     * represent the attributes of the registered user, while the values are also of String type and
     * represent the values of those attributes.
     */

    @PostMapping("/signup")
    public Map<String, String> registerUser(@RequestBody UserProfile userProfile) {
        logger.info("Registering user: {}", userProfile.getUsername());
        return authService.registerUser(userProfile);
    }

    /**
     * This function authenticates a user and generates a JWT token for them to access protected
     * resources.
     * 
     * @param userProfileDto It is an object of type UserProfileDto that is received as a request body
     * in the POST request. It contains the username and password of the user trying to authenticate.
     * @return A ResponseEntity object containing a Map of Strings with the access token and token
     * type, and an HTTP status code of OK (200).
     */
    
    @PostMapping("/login")
    public ResponseEntity<Map<String, String>> authenticateAndGetToken(@RequestBody UserProfileDto userProfileDto) {
        String username = userProfileDto.getUsername();
        logger.info("Authenticating user: {}", username);
        authenticationManager.authenticate(new UsernamePasswordAuthenticationToken(username, userProfileDto.getPassword()));
        String jwttoken = jwtService.generateToken(username);
        logger.debug("jwt token generated: {}", jwttoken);
        Map<String, String> response = new HashMap<>();
        response.put("accessToken", jwttoken);
        response.put("tokenType", "Bearer");
        return new ResponseEntity<>(response, HttpStatus.OK);
    }
    
}
