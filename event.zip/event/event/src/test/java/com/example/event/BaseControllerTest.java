package com.example.event;

import com.example.event.dto.UserProfileDto;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockHttpServletRequestBuilder;

import com.fasterxml.jackson.databind.ObjectMapper;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static  org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

@RunWith(SpringRunner.class)
@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
@AutoConfigureMockMvc
public abstract class BaseControllerTest {

    @Autowired
    protected MockMvc mockMvc;
    
    @Autowired
    private ObjectMapper objectMapper;

    public String authToken;

    protected void login(String username, String password, String role) throws Exception {
        UserProfileDto userProfileDto = new UserProfileDto();
        userProfileDto.setUsername(username);
        userProfileDto.setPassword(password);
        userProfileDto.setRole(role);

        MvcResult result = mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(objectMapper.writeValueAsString(userProfileDto)))
                .andExpect(status().isOk())
                .andReturn();

        authToken = result.getResponse().getContentAsString();

    }

    
    public MockHttpServletRequestBuilder withAuthorization(MockHttpServletRequestBuilder requestBuilder) {
        if (authToken != null) {
        requestBuilder.header(HttpHeaders.AUTHORIZATION, authToken);
        }
        return requestBuilder;
    }
    


}
