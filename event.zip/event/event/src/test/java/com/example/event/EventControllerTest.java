package com.example.event;

import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.RequestBuilder;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.example.event.dto.EventDto;
import com.example.event.entity.Event;
import com.example.event.entity.EventStatus;
import com.example.event.exception.BadRequestException;
import com.example.event.exception.ConflictException;
import com.example.event.exception.ResourceNotFound;
import com.example.event.service.EventService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.datatype.jsr310.JavaTimeModule;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = EventApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,properties = {"server.port=8080"})
@AutoConfigureMockMvc
public class EventControllerTest extends BaseControllerTest{

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;
    
    // @Test
    // @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    // public void testCreateEvent() throws Exception {

    //     login("nisha", "nisha@16", "ADMIN");
    //     DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    //     DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    //     long attendeeId=17;
    //     EventDto eventDto = new EventDto();
    //     eventDto.setEventName("fcgccfg");
    //     eventDto.setEventDescription("szsdzszsz function");
    //     eventDto.setEventStatus(EventStatus.UPCOMING);
    //     eventDto.setStartTime(LocalTime.parse("01:45",timeFormatter));
    //     eventDto.setEndTime(LocalTime.parse("10:01",timeFormatter));
    //     eventDto.setEventDate(LocalDate.parse("17-09-2015",dateFormatter));
    //     eventDto.setVenue("xcvcvhhbjb mahal");

    //     EventService eventService=mock(EventService.class);
    //     when(eventService.createEvent(attendeeId, eventDto)).thenReturn(8l);

    //     // Perform the integration test
    //     mockMvc.perform(post("/api/event/{attendeeId}", attendeeId)
    //             .contentType(MediaType.APPLICATION_JSON)
    //             .content(asJsonString(eventDto)))
    //             .andExpect(status().isOk());
    // }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testCreateEvent_NotFound() throws Exception {

        login("nisha", "nisha@16", "ADMIN");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        long attendeeId=100;
        EventDto eventDto = new EventDto();
        eventDto.setEventName("cgfcgcghgh");
        eventDto.setEventDescription("xfdxfcxfg function");
        eventDto.setEventStatus(EventStatus.UPCOMING);
        eventDto.setStartTime(LocalTime.parse("16:15",timeFormatter));
        eventDto.setEndTime(LocalTime.parse("18:06",timeFormatter));
        eventDto.setEventDate(LocalDate.parse("16-07-2023",dateFormatter));
        eventDto.setVenue("ccgghghvgh mahal");

        EventService eventService=mock(EventService.class);
        when(eventService.createEvent(attendeeId, eventDto))
        .thenThrow(new ResourceNotFound(String.valueOf(attendeeId), "Attendee is not Found.", 404));

        // Perform the integration test
        mockMvc.perform(post("/api/event/{attendeeId}", attendeeId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(eventDto)))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(String.valueOf(attendeeId)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Attendee is not Found."))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404));
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testCreateEvent_DateConflict() throws Exception {

        login("nisha", "nisha@16", "ADMIN");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        long attendeeId=11;
        EventDto eventDto = new EventDto();
        eventDto.setEventName("marriage");
        eventDto.setEventDescription("arjun sangeeth");
        eventDto.setEventStatus(EventStatus.COMPLETED);
        eventDto.setStartTime(LocalTime.parse("09:11",timeFormatter));
        eventDto.setEndTime(LocalTime.parse("08:11",timeFormatter));
        eventDto.setEventDate(LocalDate.parse("10-11-2015", dateFormatter));
        eventDto.setVenue("drfdcfctc Hall");

        EventService eventService=mock(EventService.class);
        when(eventService.createEvent(attendeeId, eventDto))
        .thenThrow(new ConflictException("Event already booked", "Event Conflict", 409));

        // Perform the integration test
        mockMvc.perform(post("/api/event/{attendeeId}", attendeeId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(eventDto)))
                .andExpect(status().isConflict())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Event already booked"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Event conflict"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statusCode").value(409));
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testCreateEvent_TimeConflict() throws Exception {

        login("nisha", "nisha@16", "ADMIN");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        long attendeeId=14;
        EventDto eventDto = new EventDto();
        eventDto.setEventName("marriage");
        eventDto.setEventDescription("arjun sangeeth");
        eventDto.setEventStatus(EventStatus.COMPLETED);
        eventDto.setStartTime(LocalTime.parse("11:16",timeFormatter));
        eventDto.setEndTime(LocalTime.parse("05:10",timeFormatter));
        eventDto.setEventDate(LocalDate.parse("05-11-2010", dateFormatter));
        eventDto.setVenue("fxfgfcf Hall");

        EventService eventService=mock(EventService.class);
        when(eventService.createEvent(attendeeId, eventDto))
        .thenThrow(new ConflictException("Event already booked", "Event Conflict", 409));

        // Perform the integration test
        mockMvc.perform(post("/api/event/{attendeeId}", attendeeId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(eventDto)))
                .andExpect(status().isConflict())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Event already booked"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Event conflict"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statusCode").value(409));
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testCreateEvent_BadRequest() throws Exception {

        login("nisha", "nisha@16", "ADMIN");
        long attendeeId=4;
        EventDto eventDto = new EventDto();

        EventService eventService=mock(EventService.class);
        when(eventService.createEvent(attendeeId, eventDto))
        .thenThrow(new BadRequestException("Invalid request", "All fields must be provided", 400));

        // Perform the integration test
        mockMvc.perform(post("/api/event/{attendeeId}", attendeeId)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"eventName\": null,\"eventStatus\":null,\"eventDate\":null," +
                "\"startTime\":null,\"endTime\":null,\"venue\":null}"))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Invalid request"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("All fields must be provided"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(400));
    }

    // @Test
    // @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    // public void testUpdateEvent() throws Exception {

    //     login("nisha", "nisha@16", "ADMIN");

    //     DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
    //     DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
    //     long eventId=5;
    //     EventDto eventDto = new EventDto();
    //     eventDto.setEventName("gvgvjh");
    //     eventDto.setEventDescription("function");
    //     eventDto.setEventStatus(EventStatus.UPCOMING);
    //     eventDto.setStartTime(LocalTime.parse("02:09",timeFormatter));
    //     eventDto.setEndTime(LocalTime.parse("08:09",timeFormatter));
    //     eventDto.setEventDate(LocalDate.parse("05-11-2008",dateFormatter));
    //     eventDto.setVenue("dxdffdfdxf");

    //     EventService eventService=mock(EventService.class);
    //     when(eventService.updateEventById(eventDto, eventId)).thenReturn("Event updated successfully");

    //     // Perform the integration test
    //     mockMvc.perform(put("/api/event/{eventId}", eventId)
    //             .contentType(MediaType.APPLICATION_JSON)
    //             .content(asJsonString(eventDto)))
    //             .andExpect(status().isOk());
    // }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testUpdateEvent_BadRequest() throws Exception {

        login("nisha", "nisha@16", "ADMIN");
        long eventId=8;
        EventDto eventDto = new EventDto();

        EventService eventService=mock(EventService.class);
        when(eventService.updateEventById(eventDto, eventId))
        .thenThrow(new BadRequestException("Invalid request", "All fields must be provided", 400));

        // Perform the integration test
        mockMvc.perform(put("/api/event/{eventId}", eventId)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"eventName\": null,\"eventStatus\":null,\"eventDate\":null," +
                "\"startTime\":null,\"endTime\":null,\"venue\":null}"))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Invalid request"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("All fields must be provided"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(400));
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testUpdateEvent_NotFound() throws Exception {

        login("nisha", "nisha@16", "ADMIN");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        long eventId=100;
        EventDto eventDto = new EventDto();
        eventDto.setEventName("marriage");
        eventDto.setEventDescription("arjun function");
        eventDto.setEventStatus(EventStatus.UPCOMING);
        eventDto.setStartTime(LocalTime.parse("16:10",timeFormatter));
        eventDto.setEndTime(LocalTime.parse("18:15",timeFormatter));
        eventDto.setEventDate(LocalDate.parse("06-01-2023",dateFormatter));
        eventDto.setVenue("hgchgcgc mahal");

        EventService eventService=mock(EventService.class);
        when(eventService.updateEventById(eventDto, eventId))
        .thenThrow(new ResourceNotFound(String.valueOf(eventId), "Event is not Found.", 404));

        // Perform the integration test
        mockMvc.perform(put("/api/event/{eventId}", eventId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(eventDto)))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(String.valueOf(eventId)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Event is not Found."))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404));
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testUpdateEvent_VenueConflict() throws Exception {

        login("nisha", "nisha@16", "ADMIN");
        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        long eventId=11;
        EventDto eventDto = new EventDto();
        eventDto.setEventName("marriage");
        eventDto.setEventDescription("arjun sangeeth");
        eventDto.setEventStatus(EventStatus.COMPLETED);
        eventDto.setStartTime(LocalTime.parse("08:01",timeFormatter));
        eventDto.setEndTime(LocalTime.parse("09:18",timeFormatter));
        eventDto.setEventDate(LocalDate.parse("09-08-2005", dateFormatter));
        eventDto.setVenue("raj mahahal");

        EventService eventService=mock(EventService.class);
        when(eventService.updateEventById(eventDto, eventId))
        .thenThrow(new ConflictException("Event already booked", "Event Conflict", 409));

        // Perform the integration test
        mockMvc.perform(put("/api/event/{eventId}", eventId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(eventDto)))
                .andExpect(status().isConflict())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Event already booked"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Event conflict"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statusCode").value(409));
    }

    // @Test
    // @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    // public void testDeleteEvent() throws Exception {

    //     login("nisha", "nisha@16", "ADMIN");
        
    //     long eventId=17;
    //     EventService eventService=mock(EventService.class);
    //     Mockito.when(eventService.deleteEventById(eventId))
    //             .thenReturn("Event Deleted Successfully");
    //     mockMvc.perform(delete("/api/event/{eventId}",eventId)
    //             .contentType(MediaType.APPLICATION_JSON))
    //             .andExpect(status().isOk());
    // }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testDeleteEvent_NotFound() throws Exception {

        login("nisha", "nisha@16", "ADMIN");
        
        long eventId=100;

        EventService eventService=mock(EventService.class);
        when(eventService.deleteEventById(eventId))
        .thenThrow(new ResourceNotFound(String.valueOf(eventId), "Event is not Found.", 404));

        // Perform the integration test
        mockMvc.perform(delete("/api/event/{eventId}", eventId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(String.valueOf(eventId)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Event is not found"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404));
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetEvent() throws Exception{

        login("nisha", "nisha@16", "ADMIN");

        long eventId = 2;

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/event/{eventId}",eventId)
            .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder)
            .andExpect(status().isOk())
            .andReturn();

        String response = result.getResponse().getContentAsString();
        Event event = objectMapper.readValue(response, new TypeReference<Event>() {});
        assertNotNull(event);
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetEvent_NotFound() throws Exception{

        login("nisha", "nisha@16", "ADMIN");

        long eventId = 100;

        EventService eventService=mock(EventService.class);
        when(eventService.getEntityById(eventId)).thenThrow(new ResourceNotFound(String.valueOf(eventId), "Event is not Found.", 404));

        mockMvc.perform(get("/api/event/{eventId}",eventId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(String.valueOf(eventId)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Event is not Found."))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404))
                .andReturn();

    }


    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetAll() throws Exception{

        login("nisha", "nisha@16", "ADMIN");

        RequestBuilder requestBuilder = MockMvcRequestBuilders.get("/api/event")
            .contentType(MediaType.APPLICATION_JSON);

        MvcResult result = mockMvc.perform(requestBuilder)
            .andExpect(status().isOk())
            .andReturn();

        String response = result.getResponse().getContentAsString();
        List<Event> events = objectMapper.readValue(response, new TypeReference<List<Event>>() {});
        assertFalse(events.isEmpty());
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetAll_StartTime() throws Exception{

        login("nisha", "nisha@16", "ADMIN");

        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        LocalTime startTime = LocalTime.parse("11:16",timeFormatter);
        List<Event> mockEvents = new ArrayList<>();

        // Create an Event object with a non-null startTime
        Event mockEvent = new Event();
        mockEvent.setStartTime(LocalTime.parse("13:01", timeFormatter));
        mockEvents.add(mockEvent);

        // Mock the service response
        EventService eventService = mock(EventService.class);
        when(eventService.readByTime(startTime)).thenReturn(mockEvents);

        // Perform the request
        MvcResult result = mockMvc.perform(get("/api/event")
                .param("startTime", String.valueOf(startTime))
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        // Verify the response
        String response = result.getResponse().getContentAsString();
        List<Event> events = objectMapper.readValue(response, new TypeReference<List<Event>>() {});
        assertFalse(events.isEmpty());
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetAll_StartTime_NotFound() throws Exception {
        login("nisha", "nisha@16", "ADMIN");

        DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HH:mm");
        LocalTime startTime = LocalTime.parse("01:01", timeFormatter);

        // Mock the service response
        EventService eventService=mock(EventService.class);
        when(eventService.readByTime(startTime)).thenThrow(new ResourceNotFound(String.valueOf(startTime), "Event is not Found in this time.", 404));

        // Perform the request
        mockMvc.perform(get("/api/event")
                .param("startTime", startTime.toString())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(String.valueOf(startTime)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Event is not Found in this time."))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404))
                .andReturn();
    }


    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetAll_EventDate() throws Exception{

        login("nisha", "nisha@16", "ADMIN");

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate eventDate = LocalDate.parse("10-11-2015",dateFormatter);
        List<Event> mockEvents = new ArrayList<>(); // Mock the events data

        // Mock the service response
        EventService eventService=mock(EventService.class);
        when(eventService.readByDate(eventDate)).thenReturn(mockEvents);

        // Perform the request
        MvcResult result = mockMvc.perform(get("/api/event")
                .param("eventDate", eventDate.toString())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        // Verify the response
        String response = result.getResponse().getContentAsString();
        List<Event> events = objectMapper.readValue(response, new TypeReference<List<Event>>() {});
        assertFalse(events.isEmpty());
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetAll_EventDate_NotFound() throws Exception {
        login("nisha", "nisha@16", "ADMIN");

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate eventDate = LocalDate.parse("01-01-2006",dateFormatter);

        // Mock the service response
        EventService eventService=mock(EventService.class);
        when(eventService.readByDate(eventDate)).thenThrow(new ResourceNotFound(String.valueOf(eventDate), "Event is not Found in this date.", 404));

        // Perform the request
        mockMvc.perform(get("/api/event")
                .param("eventDate", eventDate.toString())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(String.valueOf(eventDate)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Event is not Found in this date."))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404))
                .andReturn();
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetAll_Venue() throws Exception{

        login("nisha", "nisha@16", "ADMIN");

        String venue = "raj mahahal";
        List<Event> mockEvents = new ArrayList<>(); // Mock the events data

        // Mock the service response
        EventService eventService=mock(EventService.class);
        when(eventService.readByVenue(venue)).thenReturn(mockEvents);

        // Perform the request
        MvcResult result = mockMvc.perform(get("/api/event")
                .param("venue", venue)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        // Verify the response
        String response = result.getResponse().getContentAsString();
        List<Event> events = objectMapper.readValue(response, new TypeReference<List<Event>>() {});
        assertFalse(events.isEmpty());
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetAll_Venue_NotFound() throws Exception {
        login("nisha", "nisha@16", "ADMIN");

        String venue = "dummmy";

        // Mock the service response
        EventService eventService=mock(EventService.class);
        when(eventService.readByVenue(venue)).thenThrow(new ResourceNotFound(venue, "Event is not Found in this venue.", 404));

        // Perform the request
        mockMvc.perform(get("/api/event")
                .param("venue",venue)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(venue))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Event is not Found in this venue."))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404))
                .andReturn();
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testGetAll_FilterDates() throws Exception{

        login("nisha", "nisha@16", "ADMIN");

        DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        LocalDate startDate = LocalDate.parse("09-10-2008",dateFormatter);
        LocalDate endDate = LocalDate.parse("10-11-2015",dateFormatter);
        List<Event> mockEvents = new ArrayList<>(); // Mock the events data

        // Mock the service response
        EventService eventService=mock(EventService.class);
        when(eventService.readByRangeOfDates(startDate,endDate)).thenReturn(mockEvents);

        // Perform the request
        MvcResult result = mockMvc.perform(get("/api/event")
                .param("startDate", startDate.toString())
                .param("endDate", endDate.toString())
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andReturn();

        // Verify the response
        String response = result.getResponse().getContentAsString();
        List<Event> events = objectMapper.readValue(response, new TypeReference<List<Event>>() {});
        assertFalse(events.isEmpty());
    }


    // Utility method to convert objects to JSON string
    private static String asJsonString(Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            objectMapper.registerModule(new JavaTimeModule()); // Register the JavaTimeModule
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

}
