package com.example.event;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.put;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.delete;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.example.event.dto.AttendeeDto;
import com.example.event.entity.Attendee;
import com.example.event.exception.BadRequestException;
import com.example.event.exception.ResourceNotFound;
import com.example.event.repository.AttendeeRepository;
import com.example.event.service.AttendeeService;
import com.example.event.service.EventService;
import com.fasterxml.jackson.databind.ObjectMapper;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = EventApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,properties = {"server.port=8080"})
@AutoConfigureMockMvc
public class AttendeeControllerTest extends BaseControllerTest{

    @Autowired
    private MockMvc mockMvc;

    @Test
    @WithMockUser(username = "prasad", password = "prasad@16", roles = {"USER"})
    public void testCreateAttendee() throws Exception {

        login("prasad", "prasad@16","USER");

        AttendeeDto attendeeDto = new AttendeeDto();
        attendeeDto.setFirstname("isha");
        attendeeDto.setLastname("parasu");
        attendeeDto.setEmailAddress("isha@example.com");

        Attendee attendee = new Attendee();
        attendee.setFirstname(attendeeDto.getFirstname());
        attendee.setLastname(attendeeDto.getLastname());
        attendee.setEmailAddress(attendeeDto.getEmailAddress());

        EventService eventService = mock(EventService.class);
        when(eventService.attendeeDetails(attendeeDto)).thenReturn(attendee); // Return non-null Attendee object

        AttendeeRepository attendeeRepository = mock(AttendeeRepository.class);
        when(attendeeRepository.save(any(Attendee.class))).thenAnswer(invocation -> {
            Attendee savedAttendee = invocation.getArgument(0);
            savedAttendee.setAttendeeId(123); // Set the id to a fixed value for testing purposes
            return savedAttendee;
        });

        // Perform the POST request
        mockMvc.perform(post("/api/attendee")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(attendeeDto)))
                .andExpect(status().isOk());
    }

    @Test
    @WithMockUser(username = "prasad", password = "prasad@16", roles = {"USER"})
    public void testCreateAttendee_BadRequest() throws Exception {

        login("prasad", "prasad@16","USER");

        AttendeeDto attendeeDto = new AttendeeDto();
        
        AttendeeService attendeeService = mock(AttendeeService.class);
        when(attendeeService.createAttendee(attendeeDto)).thenThrow(
                new BadRequestException("Invalid request", "All fields must be provided", 400));
        
        mockMvc.perform(post("/api/attendee")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"firstname\": null, \"lastname\": null, \"emailAddress\": null}"))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Invalid request"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("All fields must be provided"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(400));
    }

    @Test
    @WithMockUser(username = "prasad", password = "prasad@16", roles = {"USER"})
    public void testUpdateAttendee() throws Exception {

        login("prasad", "prasad@16","USER");
       
        long attendeeId = 6;
        AttendeeDto attendeeDto = new AttendeeDto();
        attendeeDto.setFirstname("John");
        attendeeDto.setLastname("Doe");
        attendeeDto.setEmailAddress("john.doe@example.com");
        AttendeeService attendeeService = mock(AttendeeService.class);
        when(attendeeService.updateAttendeeById(attendeeDto, attendeeId)).thenReturn("Attendee Updated Successfully");

        // Act
        mockMvc.perform(put("/api/attendee/{attendeeId}", attendeeId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(attendeeDto)))
                .andExpect(status().isOk())
                .andExpect(content().string("Attendee Updated Successfully"));
    }

    @Test
    @WithMockUser(username = "prasad", password = "prasad@16", roles = {"USER"})
    public void testUpdateAttendee_BadRequest() throws Exception {

        login("prasad", "prasad@16","USER");

        long attendeeId = 2;
        AttendeeDto attendeeDto = new AttendeeDto();
        
        AttendeeService attendeeService = mock(AttendeeService.class);
        when(attendeeService.updateAttendeeById(attendeeDto,attendeeId)).thenThrow(
                new BadRequestException("Invalid request", "All fields must be provided", 400));
        
        mockMvc.perform(put("/api/attendee/{attendeeId}",attendeeId)
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"firstname\": null, \"lastname\": null, \"emailAddress\": null}"))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Invalid request"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("All fields must be provided"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(400));
    }

    @Test
    @WithMockUser(username = "prasad", password = "prasad@16", roles = {"USER"})
    public void testUpdateAttendee_NotFound() throws Exception {

        login("prasad", "prasad@16","USER");

        long attendeeId = 100;
        AttendeeDto attendeeDto = new AttendeeDto();
        attendeeDto.setFirstname("John");
        attendeeDto.setLastname("Doe");
        attendeeDto.setEmailAddress("john.doe@example.com");
        AttendeeService attendeeService = mock(AttendeeService.class);
        when(attendeeService.updateAttendeeById(attendeeDto, attendeeId))
                .thenThrow(new ResourceNotFound(String.valueOf(attendeeId), "Attendee is not Found.", 404));

        mockMvc.perform(put("/api/attendee/{attendeeId}", attendeeId)
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(attendeeDto)))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(String.valueOf(attendeeId)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Attendee is not Found."))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404));
    }

    @Test
    @WithMockUser(username = "prasad", password = "prasad@16", roles = {"USER"})
    public void testDeleteAttendee_NotFound() throws Exception {

        login("prasad", "prasad@16","USER");

        long attendeeId = 100;
    
        AttendeeService attendeeService = mock(AttendeeService.class);
        Mockito.when(attendeeService.deleteAttendeeById(attendeeId))
                .thenThrow(new ResourceNotFound(String.valueOf(attendeeId), "Attendee is not Found.", 404));
        mockMvc.perform(MockMvcRequestBuilders.delete("/api/attendee/{attendeeId}", attendeeId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(MockMvcResultMatchers.status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(String.valueOf(attendeeId)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Attendee is not Found."))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404));
    }

    @Test
    @WithMockUser(username = "prasad", password = "prasad@16", roles = {"USER"})
    public void testDeleteAttendee() throws Exception {

        login("prasad", "prasad@16","USER");

        long attendeeId = 36;
    
        AttendeeService attendeeService = mock(AttendeeService.class);
        Mockito.when(attendeeService.deleteAttendeeById(attendeeId))
                .thenReturn("Attendee Deleted Successfully");
        mockMvc.perform(delete("/api/attendee/{attendeeId}",attendeeId)
                .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk());
    }

    // Utility method to convert objects to JSON string
    private static String asJsonString(Object obj) {
        try {
            ObjectMapper objectMapper = new ObjectMapper();
            return objectMapper.writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
    
}
