package com.example.event;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertTrue;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.json.JSONObject;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.mockito.InjectMocks;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.example.event.dto.UserProfileDto;
import com.example.event.entity.UserProfile;
import com.example.event.exception.BadRequestException;
import com.example.event.exception.ResourceNotFound;
import com.example.event.filter.SecurityFilter;
import com.example.event.repository.UserInfoRepository;
import com.example.event.service.AuthenticationService;
import com.example.event.service.JwtService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import jakarta.servlet.FilterChain;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.transaction.Transactional;



@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = EventApplication.class,
        webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT,properties = {"server.port=8080"})
@AutoConfigureMockMvc
public class AuthenticationControllerTest {

    @Autowired
    private UserInfoRepository userInfoRepository;

    @Autowired
    private MockMvc mockMvc;

    @InjectMocks
	private SecurityFilter securityFilter;

    @Autowired
    private ObjectMapper objectMapper;
    
    @Autowired
    private PasswordEncoder passwordEncoder;

    @Test
    public void testRegisterUser() throws Exception {
        // Create a mock user profile
        UserProfile userProfile = new UserProfile();
        userProfile.setUsername("mockuser5");
        userProfile.setPassword("mockpassword5");
        userProfile.setRole("USER");

        // Perform the POST request to register the user
        mockMvc.perform(post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(userProfile)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("User added to the system"));

        // Verify that the user is saved in the repository
        Optional<UserProfile> savedUser = userInfoRepository.findByUsername("mockuser5");
        assertTrue(savedUser.isPresent());
        assertEquals("mockuser5", savedUser.get().getUsername());
        assertTrue(passwordEncoder.matches("mockpassword5", savedUser.get().getPassword()));
        // entityManager.flush();
        // entityManager.clear();
        // userInfoRepository.deleteByUsername("mockuser");
    }

    @Transactional
    @Test
    public void testRegisterAdmin() throws Exception {
        // Create a mock user profile
        UserProfile userProfile = new UserProfile();
        userProfile.setUsername("mockadmin5");
        userProfile.setPassword("mockpassword5");
        userProfile.setRole("ADMIN");

        // Perform the POST request to register the user
        mockMvc.perform(post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content(asJsonString(userProfile)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value("User added to the system"));

        // Verify that the user is saved in the repository
        Optional<UserProfile> savedUser = userInfoRepository.findByUsername("mockadmin5");
        assertTrue(savedUser.isPresent());
        assertEquals("mockadmin5", savedUser.get().getUsername());
        assertTrue(passwordEncoder.matches("mockpassword5", savedUser.get().getPassword()));
        // entityManager.flush();
        // entityManager.clear();
        // userInfoRepository.deleteByUsername("mockadmin");
    }
    
    @Test
    public void testRegisterUser_BadRequest() throws Exception {
        // Create a mock UserProfile with null fields to simulate a bad request
        UserProfile userProfile = new UserProfile();
        
        // Mock the authService to throw a BadRequestException when registerUser is called
        AuthenticationService authenticationService = mock(AuthenticationService.class);
        when(authenticationService.registerUser(userProfile)).thenThrow(
                new BadRequestException("Invalid request", "All fields must be provided", 400));
        
        // Perform the request and expect a 400 Bad Request response
        mockMvc.perform(MockMvcRequestBuilders.post("/api/auth/signup")
                .contentType(MediaType.APPLICATION_JSON)
                .content("{\"username\": null, \"password\": null, \"role\": null}"))
                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Invalid request"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("All fields must be provided"))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(400));
    }

    // Utility method to convert an object to JSON string
    private String asJsonString(Object object) throws JsonProcessingException {
        objectMapper = new ObjectMapper();
        return objectMapper.writeValueAsString(object);
    }

    @Test
    public void testLogin() throws Exception {
        Optional<UserProfile> user = userInfoRepository.findByUsername("nisha");
        assertTrue(user.isPresent());
        UserProfileDto request = new UserProfileDto();
        request.setUsername("nisha");
        request.setPassword("nisha@16");
        request.setRole("ADMIN");
        MvcResult mvcResult = mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(request)))
                .andExpect(status().isOk())
                .andReturn();
        String responseJson = mvcResult.getResponse().getContentAsString();
        assertNotNull(responseJson);
        JSONObject responseObj = new JSONObject(responseJson);
        String token = responseObj.getString("accessToken");
        assertNotNull(token);
        assertTrue(token.startsWith("eyJhbGciOiJIUzI1NiJ9"));
        String tokenType = responseObj.getString("tokenType");
        assertEquals("Bearer", tokenType);
    }

    @Test
    public void testLoginWithUnauthorizedError() throws Exception {
        Optional<UserProfile> user = userInfoRepository.findByUsername("nisha");
        assertTrue(user.isPresent());
        UserProfileDto request = new UserProfileDto();
        request.setUsername("nisha");
        request.setPassword("nosha");
        MvcResult mvcResult = mockMvc.perform(post("/api/auth/login")
            .contentType(MediaType.APPLICATION_JSON)
            .content(new ObjectMapper().writeValueAsString(request)))
            .andExpect(status().isUnauthorized())
            .andReturn();

            String responseBody = mvcResult.getResponse().getContentAsString();
            String expectedMessage = "Unauthorized user";
            JsonNode responseJson = new ObjectMapper().readTree(responseBody);
            String actualMessage = responseJson.get("message").asText();
            assertEquals(expectedMessage, actualMessage);
    }
    
    @Test
    public void testLoginNotFound() throws Exception {

        UserProfileDto request = new UserProfileDto();
        request.setUsername("nonExistingUser");
        request.setPassword("nisha");
        request.setRole("USER");
        mockMvc.perform(post("/api/auth/login")
                .contentType(MediaType.APPLICATION_JSON)
                .content(new ObjectMapper().writeValueAsString(request)))
                .andExpect(status().isNotFound())
                .andExpect(result -> assertFalse(result.getResolvedException() instanceof ResourceNotFound))
                .andReturn();
    }

    @Test
	public void testDoFilterInternal() throws Exception {
		
		String token = "eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiJuaXNoYSIsImlhdCI6MTY4NTAxMTUxNSwiZXhwIjoxNjg1MDEzMzE1fQ.2oYg_Xcf8gELP8pqzuGc3BvsSWQgBBlN7kHFN6aca70";
		String username = "nisha";
		String authHeader = "Bearer " + token;
		UserDetails userDetails = new User(username, "", new ArrayList<>());
		List<GrantedAuthority> authorities = new ArrayList<>(userDetails.getAuthorities());
		authorities.addAll(userDetails.getAuthorities());
		UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails,
				null, authorities);
		HttpServletRequest request = mock(HttpServletRequest.class);
		HttpServletResponse response = mock(HttpServletResponse.class);
		FilterChain filterChain = mock(FilterChain.class);
		when(request.getHeader("Authorization")).thenReturn(authHeader);
		JwtService jwtService = mock(JwtService.class);
		when(jwtService.extractUsername(token)).thenReturn(username);
		AuthenticationService userDetailsService = mock(AuthenticationService.class);
		SecurityFilter jwtAuthenticationFilter = new SecurityFilter(jwtService, userDetailsService);
		when(userDetailsService.loadUserByUsername(username)).thenReturn(userDetails);
		when(jwtService.validateToken(token, userDetails)).thenReturn(true);

		// Act
		jwtAuthenticationFilter.doFilterInternal(request, response, filterChain);

		// Assert
		verify(request, times(1)).getHeader("Authorization");
		verify(jwtService, times(1)).extractUsername(token);
		verify(userDetailsService, times(1)).loadUserByUsername(username);
		verify(jwtService, times(1)).validateToken(token, userDetails);
		verify(filterChain, times(1)).doFilter(request, response);
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		assertNotNull(authentication);
		assertEquals(authToken.getPrincipal(), authentication.getPrincipal());
		assertEquals(authToken.getAuthorities(), authentication.getAuthorities());
	}
}

