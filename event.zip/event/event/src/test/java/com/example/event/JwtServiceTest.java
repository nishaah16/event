package com.example.event;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.Mockito.when;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;


import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.runner.RunWith;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.junit.MockitoJUnitRunner;
import org.springframework.security.core.userdetails.UserDetails;

import com.example.event.service.JwtService;

import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jwts;

@RunWith(MockitoJUnitRunner.class)
public class JwtServiceTest {
    private JwtService jwtService;

    @Mock
    private UserDetails userDetails;

    @BeforeEach
    public void init() {
        MockitoAnnotations.openMocks(this);
        jwtService = new JwtService();
    }

    @Test
    void testGenerateToken() {
        String token = jwtService.generateToken("testUser");
        assertNotNull(token);
        assertTrue(token.length() > 0);
    }

    @Test
    void testExtractUsername() {
        String token = createToken("testUser", new Date(System.currentTimeMillis() + 1000 * 60 * 30));
        String username = jwtService.extractUsername(token);
        assertEquals("testUser", username);
    } 

    @Test
    void testExtractClaim() {
        Map<String, Object> claims = new HashMap<>();
        claims.put("testClaim", "testValue");
        String token = createTokenWithClaims("testUser", new Date(System.currentTimeMillis() + 1000 * 60 * 30), claims);
        String extractedClaim = jwtService.extractClaim(token, (Function<Claims, String>) claims1 -> claims1.get("testClaim", String.class));
        assertEquals("testValue", extractedClaim);
    }

    @Test
    void testValidateToken() {
        String token = createToken("testUser", new Date(System.currentTimeMillis() + 1000 * 60 * 30));
        when(userDetails.getUsername()).thenReturn("testUser");
        Boolean isValid = jwtService.validateToken(token, userDetails);
        assertTrue(isValid);
    }

    private String createToken(String username, Date expiration) {
        return Jwts.builder()
                .setSubject(username)
                .setExpiration(expiration)
                .signWith(jwtService.getSignKey())
                .compact();
    }

    private String createTokenWithClaims(String username, Date expiration, Map<String, Object> claims) {
        return Jwts.builder()
                .setSubject(username)
                .setExpiration(expiration)
                .addClaims(claims)
                .signWith(jwtService.getSignKey())
                .compact();
    }
}
