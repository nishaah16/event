package com.example.event;

import static org.junit.Assert.assertEquals;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.nio.file.Files;

import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.mock.web.MockMultipartFile;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.request.MockMvcRequestBuilders;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;

import com.example.event.controller.ImportExportController;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = EventApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
                "server.port=8080" })
@AutoConfigureMockMvc
public class ImportControllerTest extends BaseControllerTest {

    @LocalServerPort
    private int port;
    @Autowired
    private MockMvc mockMvc;

    TestRestTemplate restTemplate = new TestRestTemplate();
    @Autowired
    private ImportExportController importExportController;

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testAttendeeImportCSVData() throws Exception {

        login("nisha", "nisha@16", "ADMIN");

            File testFile = new File("C:\\Users\\NishanthiVarathan\\Desktop\\Nisha docs\\Event Booking system\\attendee list - csv.csv");
            testFile.createNewFile();
            FileWriter fileWriter = new FileWriter(testFile);
            fileWriter.write("harris,jeyaraj,harris@gmail.com\n");
            fileWriter.close();
            MockMultipartFile multipartFile = new MockMultipartFile(
                            "file",
                            "attendee list - csv.csv",
                            MediaType.TEXT_PLAIN_VALUE,
                            Files.readAllBytes(testFile.toPath()));
            mockMvc.perform(MockMvcRequestBuilders.multipart("/api/upload/attendee")
                            .file(multipartFile))
                            .andExpect(MockMvcResultMatchers.status().isOk())
                            .andReturn();
        }

        @Test
        @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
        public void testAttendeeImportExcelFile() throws Exception {

        login("nisha", "nisha@16", "ADMIN");

        String filePath = "C:\\Users\\NishanthiVarathan\\Desktop\\Nisha docs\\Event Booking system\\attendee list - excel.xlsx"; 

        MockMultipartFile excelFile = new MockMultipartFile(
                                "file", "attendee list - excel.xlsx", MediaType.MULTIPART_FORM_DATA_VALUE,
                                new FileInputStream(filePath));
        ResponseEntity<String> response = importExportController.uploadAttendee(excelFile);

        mockMvc.perform(MockMvcRequestBuilders.multipart("/api/upload/attendee")
            .file(excelFile))
            .andExpect(status().isOk());
        assertEquals("Attendee details uploaded successfully", response.getBody());
        }

        @Test
        @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
        public void testAttendeeBadRequest_FileFormat() throws Exception {
    
            login("nisha", "nisha@16", "ADMIN");
    
                File testFile = new File("test-data.pdf");
                testFile.createNewFile();
                MockMultipartFile multipartFile = new MockMultipartFile(
                                "file",
                                "test-data.pdf",
                                MediaType.TEXT_PLAIN_VALUE,
                                Files.readAllBytes(testFile.toPath()));
                mockMvc.perform(MockMvcRequestBuilders.multipart("/api/upload/attendee")
                                .file(multipartFile))
                                .andExpect(MockMvcResultMatchers.status().isBadRequest())
                                .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Invalid format"))
                                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Provide valid file format"))
                                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(400));
        }


    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testEventImportCSVData() throws Exception {

        login("nisha", "nisha@16", "ADMIN");

          long attendeeId = 11;

          String filePath = "C:\\Users\\NishanthiVarathan\\Desktop\\Nisha docs\\Event Booking system\\event list - csv.csv"; // Specify the desired file path here

            File testFile = new File(filePath);
            // testFile.createNewFile();
            // FileWriter fileWriter = new FileWriter(testFile);
            // fileWriter.write("party,marriage,COMPLETED,16:50,18:55,16-09-2001,rajam mahal\n");
            // fileWriter.close();
            MockMultipartFile multipartFile = new MockMultipartFile(
                    "file",
                    "event list - csv.csv",
                    MediaType.TEXT_PLAIN_VALUE,
                    Files.readAllBytes(testFile.toPath()));

            mockMvc.perform(MockMvcRequestBuilders.multipart("/api/upload/event")
                    .file(multipartFile)
                    .param("attendeeId", String.valueOf(attendeeId)))
                    .andExpect(MockMvcResultMatchers.status().isOk());
    }


    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testEventImportExcelFile() throws Exception {

        login("nisha", "nisha@16", "ADMIN");

            long attendeeId = 10;
            String filePath = "C:\\Users\\NishanthiVarathan\\Desktop\\Nisha docs\\Event Booking system\\event list - excel.xlsx";
            MockMultipartFile excelFile = new MockMultipartFile(
                            "file", "event list - excel.xlsx", MediaType.MULTIPART_FORM_DATA_VALUE,
                            new FileInputStream(filePath));
            mockMvc.perform(MockMvcRequestBuilders.multipart("/api/upload/event")
                            .file(excelFile)
                            .param("attendeeId", String.valueOf(attendeeId))
                            .contentType(MediaType.MULTIPART_FORM_DATA))
                            .andExpect(MockMvcResultMatchers.status().isOk())
                            .andReturn();

    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testEventBadRequest() throws Exception {

        login("nisha", "nisha@16", "ADMIN");

            long attendeeId = 8;

            File testFile = new File("test-data.pdf");
            testFile.createNewFile();
            MockMultipartFile multipartFile = new MockMultipartFile(
                            "file",
                            "test-data.pdf",
                            MediaType.TEXT_PLAIN_VALUE,
                            Files.readAllBytes(testFile.toPath()));

            mockMvc.perform(MockMvcRequestBuilders.multipart("/api/upload/event")
                            .file(multipartFile)
                            .param("attendeeId", String.valueOf(attendeeId)))
                            .andExpect(MockMvcResultMatchers.status().isBadRequest())
                            .andExpect(MockMvcResultMatchers.jsonPath("$.message").value("Invalid format"))
                            .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Provide valid file format"))
                            .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(400));
    }

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testEventImportData_NotFound() throws Exception {

        login("nisha", "nisha@16", "ADMIN");

        long attendeeId = 100;

        // Create a test file
        MockMultipartFile file = new MockMultipartFile("file", "test.csv", MediaType.TEXT_PLAIN_VALUE, "test".getBytes());

        // Act and Assert
        mockMvc.perform(MockMvcRequestBuilders.multipart("/api/upload/event")
                .file(file)
                .param("attendeeId", String.valueOf(attendeeId)))
                .andExpect(status().isNotFound())
                .andExpect(MockMvcResultMatchers.jsonPath("$.id").value(String.valueOf(attendeeId)))
                .andExpect(MockMvcResultMatchers.jsonPath("$.description").value("Attendee is not Found."))
                .andExpect(MockMvcResultMatchers.jsonPath("$.statuscode").value(404));
    }

}
