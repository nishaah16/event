package com.example.event;

import java.io.ByteArrayInputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestInstance;
import org.junit.jupiter.api.TestMethodOrder;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.mock.web.MockHttpServletResponse;
import org.springframework.security.test.context.support.WithMockUser;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;
import org.springframework.test.web.servlet.result.MockMvcResultMatchers;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;

import com.example.event.entity.Event;
import com.example.event.entity.EventStatus;
import com.example.event.repository.EventRepository;
import com.itextpdf.text.pdf.PdfPTable;
import static org.assertj.core.api.Assertions.assertThat;

@TestInstance(TestInstance.Lifecycle.PER_CLASS)
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
@RunWith(SpringRunner.class)
@SpringBootTest(classes = EventApplication.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT, properties = {
        "server.port=8080" })
@AutoConfigureMockMvc
public class ExportControllerTest extends BaseControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private EventRepository eventRepository;

    @Test
    @WithMockUser(username = "nisha", password = "nisha@16", roles = {"ADMIN"})
    public void testExportToPdf_GetAllEvents() throws Exception {

        login("nisha", "nisha@16", "ADMIN");

        DateTimeFormatter timeFormat = DateTimeFormatter.ofPattern("HH:mm");
        DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("dd-MM-yyyy");
        Event event = new Event(5, "marriage", "party", EventStatus.COMPLETED,LocalTime.parse("10:15",timeFormat),LocalTime.parse("20:15",timeFormat), LocalDate.parse("12-12-2001",dateFormat),"park");
        when(eventRepository.save(any(Event.class))).thenReturn(event);
        MvcResult mvcResult = mockMvc.perform(get("/api/event/pdf")
                .accept(MediaType.APPLICATION_PDF))
                .andExpect(MockMvcResultMatchers.status().isOk())
                .andReturn();
        MockHttpServletResponse response = mvcResult.getResponse();
        assertThat(response.getContentType()).isEqualTo(MediaType.APPLICATION_PDF_VALUE);
        assertThat(response.getHeader(HttpHeaders.CONTENT_DISPOSITION));
        byte[] pdfBytes = response.getContentAsByteArray();
        PDDocument document = PDDocument.load(new ByteArrayInputStream(pdfBytes));
        PdfPTable table = new PdfPTable(8);
        table.setWidthPercentage(100);
        table.addCell("Event Id");
        table.addCell("Event Name");
        table.addCell("Event Description");
        table.addCell("Event Status");
        table.addCell("Starting Time");
        table.addCell("Ending Time");
        table.addCell("Event Date");
        table.addCell("Event Venue");
        addTableData(table,event);
        document.close();
        eventRepository.deleteAll();

    }

    private void addTableData(PdfPTable table, Event event) {
        table.addCell(String.valueOf(event.getEventId()));
        table.addCell(event.getEventName());
        table.addCell(event.getEventDescription());
        table.addCell(event.getEventStatus().name());
        table.addCell(event.getStartTime().toString());
        table.addCell(event.getEndTime().toString());
        table.addCell(event.getEventDate().toString());
        table.addCell(event.getVenue());
    }


}


